<!DOCTYPE html>
<html lang="en-fa" >
<head>
    <meta charset="UTF-8">
    <meta name="description" content="تعمیر مارکت در زمینه تعمیرات تخصصی انواع لوازم خانگی و برد های الکترونیکی با متخصصان با تجربه آماده خدمت رسانی به شماست.">
    <link rel="stylesheet" href="css/css.min.css">
    <link rel="stylesheet" href="ItroDesign.min.css">
    <link rel="shortcut icon" href="img/favicon.ico" type="image/x-icon">
    <meta name="keywords" content=" ارج - تعمیر - تعمیرات - رفع - ایراد - ایرادات - مشکل - وسیله ی مورد نظر - ماشین - دوقلو - درب - از - بالا - در - استان - تهران - البرز - کرج - خشک - کن - دار-اتوماتیک - تعمیر مارکت - تعمیرگاه - خدمات - مجاز - مرکزی - سرویس - نصب - جاده - چالوس - زنبق -عظیمیه -بعثت - طالقانی - شمالی - طالقانی - جنوبی - میدان - اسبی - میدان - مهران - بلوار - کاج - پامچال - شمالی - پامچال - جنوبی - برغان - اسلام - اباد - آباد - ازادگان - آزادگان - حسن - اباد- آباد - نواب - مطهری - میدان - نبوت - بلوار - جمهوری - شمالی - بلوار - جمهوری - جنوبی - بلوار - موذن - اشتراکی - شمالی - اشتراکی - جنوبی - کوی - پیروزی - شهرک - بهارستان - ملکشاه - بلوار - امام - رضا - بلوار - ملاصدرا - ملا صدرا - جهانشهر - کسری - شمالی - کسری - جنوبی - بلوار - ماهان - بلوار - بهارستان - فرمانداری - رجایی - شهر - گوهر - دشت - بلوار - رستاخیز - بلوار - شهرداری - بلوار - انقلاب - اوقافی - محمود - اباد - باغستان - باغستان - غربی - خیابان - قلم - بنیاد - شاهین - ویلا - جواد - اباد - کوی - داریوش - شهرک - یاس - حصارک - بالا - حصارک - پایین - کمال - اباد - خرمدشت - پیشاهنگی - نظر - اباد - هشتگرد - شهرک - رازی - مهر - شهر- بلوار - ارم - حسین - اباد - مهرشهر - کیانمهر - فاز - 4 - مهر - شهر - 45 -متری - گلشهر - شهرک - مترو- شهرک - پردیسان - شهرک - سلمان - فارسی - دهقان - ویلای - اول - دهقان - ویلای - دوم - میانجاده - حیدر - اباد - کرج - نو - سه - راه - گوهر - دشت - بلوار - سه - باندی - کوی - داریوش - زمین - های - خانم - انصاری - کوی - کارمندان - شمالی - کوی - کارمندان - جنوبی - مهر - ویلا - بلوار - دانش - اموز - دولت - اباد - چهار - صد - دستگاه - هفت - تیر - محمد - شهر - شهرک - مهندسی - زراعی - فردیس - شهرک - وحدت - شهرک - منظریه - ساسانی - فردوسی - رزکان - نو - قلمستان - مصباح - کلاک - بالا - کلاک - پایین - کلاک -  شهرداری - گرمدره - شهرک - جهان - نما - شهرک - خاتم - حسین - آباد - راهن - راه - آهن - اهن - جاده - چالوس - زنبق - عظیمیه - بعثت - طالقانی - شمالی - طالقانی - جنوبی - میدان - اسبی - میدان - مهران - بلوار - کاج - پامچال - شمالی - پامچال - جنوبی - برغان - اسلام - اباد - ازادگان - حسن - اباد - نواب - مطهری - میدان - نبوت - بلوار - جمهوری - شمالی - بلوار - جمهوری - جنوبی - بلوار - موذن - اشتراکی - شمالی - اشتراکی - جنوبی - کوی - پیروزی - شهرک - بهارستان - ملکشاه - بلوار - امام - رضا - بلوار - ملا - صدرا - ملاصدرا - جهانشهر - کسری - شمالی - کسری - جنوبی - بلوار - ماهان - بلوار - بهارستان - فرمانداری - رجایی - شهر - گوهر - دشت - بلوار - رستاخیز - بلوار - شهرداری - بلوار - انقلاب - اوقافی - محمود - اباد - باغستان - باغستان - غربی - خیابان - قلم - بنیاد - شاهین - ویلا - جواد - اباد - کوی - داریوش - شهرک - یاس - حصارک - بالا - حصارک - پایین - کمال - اباد - خرمدشت - پیشاهنگی - نظر - اباد - هشتگرد - شهرک - رازی - مهر - شهر - بلوار - ارم - حسین - اباد - مهر - شهر - کیانمهر - کیان - مهر - فاز - چهار - 4 - مهر - شهر - 45متری - چهل - و- پنج - متری - گلشهر - شهرک - مترو - شهرک - پردیسان - شهرک - سلمان - فارسی - دهقان - ویلای - اول - دهقان - ویلای - دوم - میانجاده - حیدر - اباد - کرج - نو - سه - راه - گوهر - دشت - بلوار - سه - باندی - کوی - داریوش - زمین - های - خانم - انصاری - کوی - کارمندان - شمالی - کوی - کارمندان - جنوبی - مهر - ویلا - بلوار - دانش - اموز - آموز - دولت - اباد - چهار - صد - دستگاه - هفت - تیر - محمد - شهر - شهرک - مهندسی - زراعی - فردیس - شهرک - وحدت - شهرک - منظریه - ساسانی - فردوسی - رزکان - نو - قلمستان - مصباح - کلاک - بالا - کلاک -پایین - کلاک - شهرداری - گرمدره - شهرک - جهان - نما - شهرک - خاتم - حسین - آباد - راهن - منیریه - گمرک - نازی‌ - آباد - خانی‌ - آباد - خزانه - کیان‌ - شهر - بریانک - پیروزی - نیرو - هوایی - صفا - افسریه - بهارستان - دروازه - شمیران - شکوفه - مشیریه - شهر - ری - نازی - آباد - میدان - خراسان - خاوران - سعادت - آباد - شهرک - غرب - پونک - جی - باغ فیض - شهران - ستارخان - صادقیه - گیشا - اکباتان - سردار - جنگل - کاشانی - المپیک - آزادی - درکه - تهرانسر - شهرآرا - شهرزیبا - مرزداران - فردوس - اوین - ایوانک - نیاوران - دزاشیب - پاسداران - فرمانیه - ازگل - ارتش - تجریش - زعفرانیه - قیطریه - چیذر - اختیاریه - قلهک - ظفر - میرداماد - جردن - نوبنیاد - نو بنیاد - شریعتی - هفت تیر - یوسف آباد - سهروردی - وزرا - الهیه - گاندی - تهرانپارس - حکیمیه - رسالت - هفت - حوض - سراج - دلاوران - شمیران - نو - هنگام - نارمک - مجیدیه - بهار - سبلان - دردشت - نظام - آباد - علم - و - صنعت - پیروزی - پلیس - کرمان - مدنی - امام - حسین - تهران - نو">
    
    <title>تعمیرات ظرفشویی پاناسونیک | تعمیر مارکت</title>
</head>
<body class="styles-of-body-tag">
        <header class="position-of-menu style-of-menu">
        <div class="style-of-all-menu display-none-mo">
            <div>
                <div>
                    <img onclick="dispalymenuitems()" src="img/menu/menu icon.png" id="display-of-menu-icon"     alt="تعمیر مارکت" class="style-of-menu-icon-in-mo"></img>
                    <img onclick="bardispalymenuitems()" src="img/menu/zarbdar.png" id="display-of-menu-zarbdar" alt="تعمیر مارکت" class="style-of-menu-icon-zarbdar-in-mo"></img>
                        <nav id="style-of-all-menu-mo">
                            <ul class="display-inline">
                                <li class="display-inline"><a class="style-of-sdf style-of-original-page-item-in-menu-for-mo z-index-of-orginal-item-of-menu" href="index.php">صفحه ی اصلی </a></li>
                                <div onmouseover="showzirmajmoee()" class="style-of-temirat-in-menu-and-open-or-close">
                                    <li  class="display-inline z-index-of-orginal-item-of-menu"> <a class="style-of-sdf z-index-of-orginal-item-of-menu">تعمیرات</a>
                                       <div class="display-inline" onmouseover="showzirmajmoee()" onmouseout="hidezirmajmoee()">
                                         <ul id="style-of-zirmenu-of-tamirat" class="style-of-zirmenu-of-tamirat">
                                            <li onmouseover="showzirmajmoee2()" onmouseout="hidezirmajmoee2()" class="style-of-sdf background-color-0e4797-hover"><a class="style-of-text-of-zirmenus style-of-sdf"  >لوازم خانگی</a>
                                                <ul id="style-of-zirmenu-of-tamirat2" class="style-of-zirmenu-of-tamirat2" class="style-of-all-of-zirmajmoee">
                                                    <li class="style-of-sdf"><a class="style-of-text-of-zirmenus style-of-sdf" title="تعمیرات ماشین لباسشویی | تعمیر مارکت" href="RepairWashingMachine.php"> ماشین لباسشویی</a></li>
                                                    <li class="style-of-sdf"><a class="style-of-text-of-zirmenus style-of-sdf" title="تعمیرات یخچال فریزر | تعمیر مارکت" href="RepairRefrigerator.php">یخچال/فریزر </a></li>
                                                    <li class="style-of-sdf"><a class="style-of-text-of-zirmenus style-of-sdf" title="تعمیرات ساید بای ساید | تعمیر مارکت" href="RepairSideBySide.php">ساید بای ساید</a></li>
                                                    <li class="style-of-sdf"><a class="style-of-text-of-zirmenus style-of-sdf" title="تعمیرات ظرفشویی | تعمیر مارکت" href="RepairDishwasher.php"> ظرفشویی</a></li>
                                                    <li class="style-of-sdf"><a class="style-of-text-of-zirmenus style-of-sdf" title="تعمیرات ماکروفر ( سولاردام ، ماکروویو ) | تعمیر مارکت" href="RepairMicrowave.php"> ماکروویو</a></li>
                                                    <li class="style-of-sdf"><a class="style-of-text-of-zirmenus style-of-sdf" title="تعمیرات کولر آبی و گازی | تعمیر مارکت" href="RepairAirConditioning.php"> کولر آبی/گازی</a></li>
                                                    <li class="style-of-sdf"><a class="style-of-text-of-zirmenus style-of-sdf" title="تعمیرات جاروبرقی | تعمیر مارکت" href="RepairVacuumeCleaner.php"> جاروبرقی </a></li>
                                                    <li class="style-of-sdf"><a class="style-of-text-of-zirmenus style-of-sdf" title="تعمیرات لوازم برقی آشپزخانه | تعمیر مارکت" href="RepairKitchenAppliances.php">لوازم آشپزخانه </a></li>
                                                </ul>
                                            </li>
                                            <br class="display-none-pc">
                                            <li onmouseover="showzirmajmoee3()" onmouseout="hidezirmajmoee3()" class="style-of-sdf border-top-of-menu"><a class="style-of-text-of-zirmenus"  >برد های الکترونیکی</a>
                                                <ul id="style-of-zirmenu-of-tamirat3" class="style-of-zirmenu-of-tamirat3">
                                                    <li class="style-of-sdf"><a class="style-of-text-of-zirmenus">
                                                         <a class="style-of-text-of-zirmenus style-of-sdf" title="تعمیرات برد الکترونیکی لوازم خانگی | تعمیر مارکت" href="RepairHomeBoard.php">برد لوازم خانگی</a> 
                                                    </li>
                                                    <li class="style-of-sdf"><a class="style-of-text-of-zirmenus">
                                                         <a class="style-of-text-of-zirmenus style-of-sdf" title="تعمیرات برد های الکترونیکی دستگاه های صنعتی | تعمیر مارکت" href="RepairFactoryBoard.php">برد دستگاه های صنعتی</a> 
                                                    </li>
                                                </ul>
                                            </li>
                                            <br class="display-none-pc">
                                            <!-- سیم پیچی = sim -->
                                            <li onmouseover="showzirmajmoee4()" onmouseout="hidezirmajmoee4()" class="style-of-sdf border-top-of-menu"><a class="style-of-text-of-zirmenus"  >سیم پیچی موتور</a>
                                                <ul id="style-of-zirmenu-of-tamirat4" class="style-of-zirmenu-of-tamirat4">
                                                    <li class="style-of-sdf">
                                                         <a class="style-of-text-of-zirmenus" title="سیم پیچی موتور تک فاز | تعمیر مارکت" href="SimSeFazMotor.php">سه فاز</a> 
                                                    </li>
                                                    <br class="display-none-pc">
                                                    <li class="style-of-sdf">
                                                        <a class="style-of-text-of-zirmenus" title="سیم پیچی موتور سه فاز | تعمیر مارکت" href="SimTakFazMotor.php">تک فاز</a>
                                                    </li>
                                                    <br class="display-none-pc">
                                                    <li class="style-of-sdf">
                                                        <a class="style-of-text-of-zirmenus" title="سیم پیچی موتور ترانس | تعمیر مارکت" href="SimTrans.php">ترانس</a>
                                                    </li>
                                                </ul>
                                            </li>
                                        </ul>  
                                       </div>
                                        
                                    </li>
                                </div>
                                    <br class="display-none-pc">
                                    <li class="display-inline z-index-of-orginal-item-of-menu"> <a href="errors/errors.php" class="style-of-sdf z-index-of-orginal-item-of-menu">ارور ها</a></ul>
                                    </li>
                                <br class="display-none-pc">
                                <li class="display-inline"><a class="style-of-sdf" href="learn.php">آموزش</a></li>
                                <br class="display-none-pc">
                                <li class="display-inline"><a class="style-of-sdf" href="EtalaatOmomee.php">بیشتر بدانیم</a></li>
                                <br class="display-none-pc">
                                <li class="display-inline"><a class="style-of-sdf" href="AboutUs.php">درباره ما</a></li>
                                <br class="display-none-pc">
                                <li class="display-inline"><a class="style-of-sdf" href="ContactUs.php">تماس با ما</a></li>
                                <br class="display-none-pc">
                                <li class="display-inline style-of-sabt-sefaresh-li-in-menu"><a class="style-of-sdf style-of-sabt-sefaresh-in-menu" href="SabtSefaresh.php">ثبت سفارش</a></li>
                                <br class="display-none-pc">
                            </ul>
                        </nav>
                    </div>
                </div>
            </div>
            <!-- منوی موبایل زیر منوی کامپیوتر بالا -->
            <div id="style-of-all-menu" class="style-of-all-menu display-none-pc">
                <div>
                    <div>
                        <img onclick="ChangeAlamatOfMenu()" id="style-hamberger-in-menu-mo" class="style-hamberger-in-menu-mo" src="img/menu/menu icon.png"  alt="تعمیر مارکت"></img>
                        <img onclick="ChangeAlamatOfMenu()" id="style-x-in-menu-mo" class="style-x-in-menu-mo" src="img/menu/zarbdar.png"    alt="تعمیر مارکت"></img>
                            <nav id="display-of-all-menu-in-mo" class="display-of-all-menu-in-mo">
                                <ul>
                                    <li  class="style-of-menu-text-in-mo"><a  class="style-of-menu-text-in-mo" href="index.php">صفحه ی اصلی </a></li>
                                    <div><hr class="white-hr">
                                        <li class="style-of-menu-text-in-mo"><a class="style-of-menu-text-in-mo" onclick="displayOfZirMenuInMo1()">تعمیرات</a><hr class="white-hr">
                                           <div id="display-of-zir-menu-in-mo1" class="display-of-zir-menu-in-mo1">
                                             <ul>
                                                <li class="style-of-menu-text-in-mo" onclick="displayOfZirMenuInMo2()"><a>لوازم خانگی</a><hr class="white-hr">
                                                    <ul id="display-of-zir-menu-in-mo2" class="display-of-zir-menu-in-mo2">
                                                        <li class="style-of-menu-text-in-mo"><a class="style-of-menu-text-in-mo" href="RepairWashingMachine.php"> ماشین ظرفشویی</a></li><hr class="white-hr">
                                                        <li class="style-of-menu-text-in-mo"><a class="style-of-menu-text-in-mo" href="RepairRefrigerator.php">یخچال/فریزر </a></li><hr class="white-hr">
                                                        <li class="style-of-menu-text-in-mo"><a class="style-of-menu-text-in-mo" href="RepairSideBySide.php">ساید بای ساید</a></li><hr class="white-hr">
                                                        <li class="style-of-menu-text-in-mo"><a class="style-of-menu-text-in-mo" href="RepairDishwasher.php"> ماشین ظرفشویی</a></li><hr class="white-hr">
                                                        <li class="style-of-menu-text-in-mo"><a class="style-of-menu-text-in-mo" href="RepairMicrowave.php"> ماکروویو</a></li><hr class="white-hr">
                                                        <li class="style-of-menu-text-in-mo"><a class="style-of-menu-text-in-mo" href="RepairAirConditioning.php"> کولر آبی/گازی</a></li><hr class="white-hr">
                                                        <li class="style-of-sdf"><a class="style-of-text-of-zirmenus style-of-sdf" title="تعمیرات جاروبرقی | تعمیر مارکت" href="RepairVacuumeCleaner.php"> جاروبرقی </a></li>
                                                        <li class="style-of-menu-text-in-mo"><a class="style-of-menu-text-in-mo" href="RepairKitchenAppliances.php">لوازم آشپزخانه </a></li><hr class="white-hr">
                                                    </ul>
                                                </li>
                                                <li class="style-of-menu-text-in-mo" onclick="displayOfZirMenuInMo3()"><a>برد های الکترونیکی</a><hr class="white-hr">
                                                    <ul id="display-of-zir-menu-in-mo3" class="display-of-zir-menu-in-mo3">
                                                        <li class="style-of-menu-text-in-mo">
                                                             <a class="style-of-menu-text-in-mo" href="RepairHomeBoard.php">برد لوازم خانگی</a> <hr class="white-hr">
                                                        </li>
                                                        <li class="style-of-menu-text-in-mo">
                                                             <a class="style-of-menu-text-in-mo" href="RepairFactoryBoard.php">برد دستگاه های صنعتی</a> <hr class="white-hr">
                                                        </li>
                                                    </ul>
                                                </li>
                                                <!-- سیم پیچی = sim -->
                                                <li class="style-of-menu-text-in-mo" onclick="displayOfZirMenuInMo4()"><a>سیم پیچی موتور</a><hr class="white-hr">
                                                    <ul id="display-of-zir-menu-in-mo4" class="display-of-zir-menu-in-mo4">
                                                        <li class="style-of-menu-text-in-mo">
                                                             <a class="style-of-menu-text-in-mo" href="SimSeFazMotor.php">سه فاز</a> <hr class="white-hr">
                                                        </li>
                                                        <li class="style-of-menu-text-in-mo">
                                                            <a class="style-of-menu-text-in-mo" href="SimTakFazMotor.php">تک فاز</a><hr class="white-hr">
                                                        </li>
                                                        <li class="style-of-menu-text-in-mo">
                                                            <a class="style-of-menu-text-in-mo" href="SimTrans.php">ترانس</a><hr class="white-hr">
                                                        </li>
                                                    </ul>
                                                </li>
                                            </ul>  
                                           </div>
                                            
                                        </li>
                                    </div>
                                        <li class="style-of-menu-text-in-mo"> <a class="style-of-menu-text-in-mo" href="errors/errors.php">ارور ها</a><hr class="white-hr">
                                        </li>
                                    <li class="style-of-menu-text-in-mo"><a class="style-of-menu-text-in-mo" href="learn.php">آموزش</a></li><hr class="white-hr">
                                    <li class="style-of-menu-text-in-mo"><a class="style-of-menu-text-in-mo" href="EtalaatOmomee.php">بیشتر بدانیم</a></li><hr class="white-hr">
                                    <li class="style-of-menu-text-in-mo"><a class="style-of-menu-text-in-mo" href="AboutUs.php">درباره ما</a></li><hr class="white-hr">
                                    <li class="style-of-menu-text-in-mo"><a class="style-of-menu-text-in-mo" href="ContactUs.php">تماس با ما</a></li><hr class="white-hr">
                                    <li class="style-of-menu-text-in-mo"><a class="style-of-menu-text-in-mo" href="SabtSefaresh.php">ثبت سفارش</a></li><hr class="white-hr">
                                </ul>
                            </nav>
                        </div>
                    </div>
                </div>
        </header>
    <p id="show-menu-button" onclick="show_menu_desktop()" class="style-show-menu-button"> < </p>
    <div class="first-logo-styles">
         
        <img class="display-inline styles-of-first-logo-in-all-pages-1" src="img/firstlogo/لوگوی تعمیر مارکت.png"alt="Tamir Market تعمیر مارکت">
        <img class="display-inline styles-of-first-logo-in-all-pages-2" src="img/firstlogo/تعمیر مارکت.png" alt="Tamir Market تعمیر مارکت">
        <hr class="style-of-hr-in-bottom-of-first-logo-in-all-pages">
    </div>
    <br>
    <div class="style-of-moarefi-shoql-box">
        <h2 class="style-of-moarefi-shoql">
            خدمات پس از فروش تعمیرات لوازم خانگی 
        </h2>
        <h2 class="style-of-moarefi-shoql2">
            مرکز تخصصی تعمیرات
            <br>
            لباسشویی , ظرفشویی, ساید بای ساید , یخچال, کولر گازی و آبی, مایکروویو , جاروبرقی
        </h2>
    </div>
    <br>
    <br>
    <div id="slider"></div>
    <div class="right">
    <img class="style-of-orginal-brand-image" src="img/OrginalBrandImage/zarfshooi/ل پاناسونیک.jpg" alt="تعمیرات ظرفشویی پاناسونیک">
    <br><br>
        <h2 class="animation-of-title-brand">
            تعمیرات تخصصی ماشین ظرفشویی پاناسونیک 
        </h1>
        <div><a><img class="style-of-brand-img-in-brand-page2" src="img/brand images/PANASONIC.png"                    alt="تعمیر مارکت"></a></div>    
        <br>
        <h2 class="style-of-moarefi-shoql">
            عضو رسمی اتحادیه تعمیرکاران لوازم خانگی
        </h2>
        <br>
        <p class="style-of-mazit-estfade-az-ma">مزیت استفاده از خدمات تعمیرات ظرفشویی تعمیر مارکت :</p>
        <p class="style-of-mazit-estfade-az-ma-text">  1) استفاده از برترین تعمیرکاران(سرویس کاران) و متخصصین در تعمیرات ظرفشویی پاناسونیک</p>
        <p class="style-of-mazit-estfade-az-ma-text">  2) استفاده از لوازم و قطعات اصلی (اورجینال ) در تعمیرات ظرفشویی </p>
        <p class="style-of-mazit-estfade-az-ma-text">  3) تمامی خدمات تعمیر مارکت دارای 100 روز گارانتی بی قید و شرط می باشد</p>
        <br><br>
        <div><a><img class="style-of-brand-img-in-brand-page2" src="img/brand images/PANASONIC 2.png"                    alt="تعمیر مارکت"></a></div>    
        <br><br>
        <p class="style-of-mazit-estfade-az-ma">چرا شما برای نصب، سرویس وتعمیرات لوازم خانگی خود تعمیر مارکت را انتخاب کنید ؟</p>
        <p class="style-of-mazit-estfade-az-ma-text">
        مرکز تعمیر مارکت در استان تهران و البرز (کرج) در زمینه نصب، سرویس وتعمیرات  انواع لوازم خانگی
        (ظرفشویی، ظرفشویی، یخچال، ماکروویو، جاروبرقی و کولرگازی) پاناسونیک در خدمت شماست.
        <br>
         تعمیر مارکت قابل اعتماد ترین بهترین وسریع ترین خدمات ممکن را به شما ارائه خواهد کرد و بهترین گزینه برای انتخاب شما در استان تهران و البرز (کرج) میباشد 
        <br>
        در صورتی که لوازم خانگی شما به هر دلیلی از جمله (نمایش کد خطا یا ارور، متوقف شدن یا سر و صدای زیاد و... ) دارای مشکل باشد، این مجموعه یکی از بهترین تعمیرکاران متخصص خود را برای انجام تعمیر لوازم خانگی شما اعزام خواهد کرد . 
        <br>
        تمام تعمیرکاران و تکنسین های ما دوره های آموزشی تعمیرات لوازم خانگی پاناسونیک را در مدل ها و محصولات مختلف پاناسونیک، گذرانده اند.
        <br>
        تعمیر مارکت جهت جلب رضایت شما تمامی خدمات انجام شده را به مدت 
        صد روز  ضمانت بی قید و شرط می نماید.  
        </p>
        <br><br>
        <div class="style-of-vipsabtsefaresh-box">
            <div class="style-of-vipsabtsefaresh1">
                ثبت سفارش آنلاین
            </div>
            <div class="style-of-vipsabtsefaresh2">
                در صورت ثبت سفارش آنلاین از ۵ درصد تخفیف شرکت بهره مند شوید!
            </div>
        </div>


         <!-- شروع شرایط گارانتی سانیاران -->
 <!-- ============================================================================================================================================================================================================================================================== -->
 <!-- ============================================================================================================================================================================================================================================================== -->
 <!-- ============================================================================================================================================================================================================================================================== -->
        <br><br>
        <hr class="style-of-re-hr">
        <br><br>
        <table class="display-none-mo">
        <tr>
            <td class="width-30-100">
            <img src="img/sharayetegarantyimg.gif" alt="شرایط گارانتی سانیاران">
            </td>
            <td class="width-70-100">
            <p class="font-size-40 text-center font-family-yekan-plus-bold text-color-green-5">تعمیر مارکت</p>
            <p class="font-size-20 text-center font-family-yekan-plus-bold">تعمیرات تخصصی لوازم خانگی</p>
            <p class="direction-rtl font-family-yekan-plus-bold">
            <span class="text-color-green-5 style-ra-text">۱) اگر لوازم خانگی شما دارای گارانتی مفید از خود شرکت سازنده باشد ، در
                   صورت بروز هرگونه ایراد با شرکت مربوطه تماس حاصل فرمایید
                   تا از مزایای گارانتی بهره مند شوید.
                  <br>
            <span class="text-color-green-5 style-ra-text">۲)</span> در صورتی که لوازم خانگی شما مدت زمان گارانتی
                    ان به اتمام رسیده و یا برگه ی گارانتی ان مفقود گردیده است . میتوانید با تماس با تعمیر مارکت از تمامی خدمات ما استفاده       
                    نمایید        
                  <br>
             <span class="text-color-green-5 style-ra-text">۳)</span> تمامی خدمات مجموعه ی تعمیر مارکت دارای<span class="text-color-red-6 style-ra-text">  ۱۰۰ روز گارانتی بی قید و شرط</span> می باشد 
            </p>
            </td>
            </tr>
        </table>

<table class="display-none-pc">
        <tr>
            <td class="width-100-100-mo">
            <img class="style-sharayet-garanty-img" src="img/sharayetegarantyimg.gif" alt="شرایط گارانتی سانیاران">
            </td>
        </tr>
        <tr>
            <td class="width-100-100-mo">
            <p class="font-size-40 text-center font-family-yekan-plus-bold text-color-green-5">تعمیر مارکت</p>
            <p class="font-size-20 text-center font-family-yekan-plus-bold">تعمیرات تخصصی لوازم خانگی</p>
            <p class="direction-rtl font-family-yekan-plus-bold">
            <span class="text-color-green-5 style-ra-text">۱) اگر لوازم خانگی شما دارای گارانتی مفید از خود شرکت سازنده باشد ، در
                   صورت بروز هرگونه ایراد با شرکت مربوطه تماس حاصل فرمایید
                   تا از مزایای گارانتی بهره مند شوید.
                  <br><br>
            <span class="text-color-green-5 style-ra-text">۲)</span> در صورتی که لوازم خانگی شما مدت زمان گارانتی
                    ان به اتمام رسیده و یا برگه ی گارانتی ان مفقود گردیده است . میتوانید با تماس با تعمیر مارکت از تمامی خدمات ما استفاده       
                    نمایید        
                  <br><br>
             <span class="text-color-green-5 style-ra-text">۳)</span> تمامی خدمات مجموعه ی تعمیر مارکت دارای<span class="text-color-red-6 style-ra-text">  ۱۰۰ روز گارانتی بی قید و شرط</span> می باشد 
            </p>
            </td>
            </tr>
        </table>
        <br><br>
        <hr class="style-of-re-hr">
        <br><br>
 <!-- پایان شرایط گارانتی سانیاران -->
 <!-- ============================================================================================================================================================================================================================================================== -->
 <!-- ============================================================================================================================================================================================================================================================== -->
 <!-- ============================================================================================================================================================================================================================================================== -->
  
        <div><a><img class="style-of-brand-img-in-brand-page2" src="img/brand images/PANASONIC 2.png"                    alt="تعمیر مارکت"></a></div>    
        <br><br>
        <img class="style-of-rah-haye-ertebaty-gif" src="img/rahhayeertebaty.png" alt="راه های ارتباط با ما">
        <p class="about-brand-title">درباره ماشین ظرفشویی</p>
        <p class="about-brand-text">
            ماشین ظرف‌شویی یک دستگاه مکانیکی برقی است که برای شستن و تمیز کردن ظرف‌ها و وسایل خوردن به کار می‌رود. از ماشین ظرف‌شویی در رستوران‌ها و آشپزخانه‌های منازل استفاده می‌شود.
            نخستین ماشین ظرف‌شویی را یک زن ثروتمند به نام جوزفین کاکرن در سال ۱۸۸۶ اختراع کرد و آن را در نمایشگاه جهانیِ شیکاگو در ۱۸۹۳ به نمایش گذاشت.
        +</p>

        <img class="style-of-orginal-brand-image" src="img/Lavazem Khanegy Images/DW/001.png" alt="تعمیرات ظرفشویی پاناسونیک">
        <br><br>
        <p class="about-brand-title">مشکلات رایج انواع ماشین های ظرفشویی</p>
        <p class="style-of-mazit-estfade-az-ma-text">  1) وجود سر و صدای غیر طبیعی در هنگام کار ماشین</p>
        <p class="style-of-mazit-estfade-az-ma-text">  2) خشک نشدن ظروف پس از عملیات شستشو </p>
        <p class="style-of-mazit-estfade-az-ma-text">  3) نشتی آب در ماشین ظرفشویی</p>
        <p class="style-of-mazit-estfade-az-ma-text">  4) آبگیری نکردن ماشین ظرفشویی</p>
        <p class="style-of-mazit-estfade-az-ma-text">  5) روشن نشدن ماشین ظرفشویی</p>
        <p class="style-of-mazit-estfade-az-ma-text">  6) ایجا بوی بد و نامطبوع از ماشین ظرفشویی</p>
        <p class="style-of-mazit-estfade-az-ma-text">  7) بیش از حد معمول زمان بردن فرآیند کار ماشین ظرفشویی</p>

    </div>
    <div class="left">
        <img class="style-of-left-ra" src="img/left/orginal.png" alt="chatre sabz">
        <p>این بخش به زودی در دسترس خواهدبود</p>
    </div>
    <br><br>
    <table class="style-of-original-title-why-this-co">
        <tr class="style-of-original-title-why-this-co border-none">
            <td class="style-of-original-title-why-this-co border-none">
                <p class="why-this-co style-of-original-title-why-this-co border-none">چرا تعمیر مارکت</p>
            </td>
        </tr>
    </table>
    <table class="style-of-zir-why-this-co-box">
                   
        <tr>
          <td class="style-of-zir-why-this-co-td">
              <img class="style-of-zir-why-this-co-img" src="img/why this co/ساعت.png" alt="سرعت در عملکرد"><h5 class="style-of-zir-why-this-co-title-text">سرعت در عملکرد</h5><p class="style-of-zir-why-this-co-text">
                  عیب یابی سریع و رفع ایرادات
          </p></td>
          <td class="style-of-zir-why-this-co-td"><img class="style-of-zir-why-this-co-img" src="img/why this co/کامیون.png" alt="حمل رایگان"><h5 class="style-of-zir-why-this-co-title-text">حمل رایگان</h5><p class="style-of-zir-why-this-co-text">
                  حمل ایمن لوازم خانگی شما در صورت نیاز
          </p></td>
          <td class="style-of-zir-why-this-co-td"><br><img class="style-of-zir-why-this-co-img" src="img/why this co/پول.png" alt="اطلاع رسانی هزینه ها"><h5 class="style-of-zir-why-this-co-title-text">اطلاع رسانی هزینه ها</h5><p class="style-of-zir-why-this-co-text">
                  اعلام براورد هزینه ها قبل از اعزام تعمیرکار
          </p></td>
        </tr>
        <tr>
          <td class="style-of-zir-why-this-co-td"><br>
            <img class="style-of-zir-why-this-co-img" src="img/why this co/تابلو راهنما.png" alt="مشاوره رایگان"><h6 class="style-of-zir-why-this-co-title-text">مشاوره رایگان</h6><p class="style-of-zir-why-this-co-text">
                  پاسخگویی و ارائه مشاوره در امر خرید و تعمیرات
          <td class="style-of-zir-why-this-co-td"><br>
            <img class="style-of-zir-why-this-co-img" src="img/why this co/تخته شاسی.png" alt="گارانتی"><h6 class="style-of-zir-why-this-co-title-text">گارانتی</h6><p class="style-of-zir-why-this-co-text">
                  ضمانت ۱۰۰ روزه خدمات ارائه شده
          </p></td>
          <td class="style-of-zir-why-this-co-td">
            <img class="style-of-zir-why-this-co-img" src="img/why this co/آچار پیچ گوشتی.png" alt="تجربه"><h6 class="style-of-zir-why-this-co-title-text"> تجربه </h6><p class="style-of-zir-why-this-co-text">
            با بیش از 2 دهه تجربه مفید در ارائه خدمات
          </p></td>
        </tr>
    </table>
      
    
    <table class="style-of-zir-why-this-co-box-mo">
                   
          <tr>
          <td class="style-of-zir-why-this-co-td"><img class="style-of-zir-why-this-co-img" src="img/why this co/ساعت.png" alt="سرعت در عملکرد"><h5 class="style-of-zir-why-this-co-title-text">سرعت در عملکرد</h5><p class="style-of-zir-why-this-co-text">
                  عیب یابی سریع و رفع ایرادات
          </p></td>
          </tr>
          <tr>
          <td class="style-of-zir-why-this-co-td"><img class="style-of-zir-why-this-co-img" src="img/why this co/کامیون.png" alt="حمل رایگان"><h5 class="style-of-zir-why-this-co-title-text">حمل رایگان</h5><p class="style-of-zir-why-this-co-text">
                  حمل ایمن لوازم خانگی شما در صورت نیاز
          </p></td>
          </tr>
          <tr>
          <td class="style-of-zir-why-this-co-td"><br><img class="style-of-zir-why-this-co-img" src="img/why this co/پول.png" alt="اطلاع رسانی هزینه ها"><h5 class="style-of-zir-why-this-co-title-text">اطلاع رسانی هزینه ها</h5><p class="style-of-zir-why-this-co-text">
                  اعلام براورد هزینه ها قبل از اعزام تعمیرکار
          </p></td>
          </tr>
          <tr>
          <td class="style-of-zir-why-this-co-td"><br>
            <img class="style-of-zir-why-this-co-img" src="img/why this co/تابلو راهنما.png" alt="مشاوره رایگان"><h6 class="style-of-zir-why-this-co-title-text">مشاوره رایگان</h6><p class="style-of-zir-why-this-co-text">
                  پاسخگویی و ارائه مشاوره در امر خرید و تعمیرات
          </p></td>
          </tr>
          <tr>
          <td class="style-of-zir-why-this-co-td"><br>
            <img class="style-of-zir-why-this-co-img" src="img/why this co/تخته شاسی.png" alt="گارانتی"><h6 class="style-of-zir-why-this-co-title-text">گارانتی</h6><p class="style-of-zir-why-this-co-text">
                  ضمانت ۱۰۰ روزه خدمات ارائه شده
          </p></td>
          </tr>
          <tr>
          <td class="style-of-zir-why-this-co-td">
            <img class="style-of-zir-why-this-co-img" src="img/why this co/آچار پیچ گوشتی.png" alt="تجربه"><h6 class="style-of-zir-why-this-co-title-text"> تجربه </h6><p class="style-of-zir-why-this-co-text">
            با بیش از 2 دهه تجربه مفید در ارائه خدمات
          </p></td>
          </tr>
    </table>
    <br><br>
    <p class="style-of-new-news">
        آموزش های تخصصی
    </p>
    <br><br>
    <div class="display-none-mo">
        <div class="style-of-ItemTamirat-radif style-of-ItemTamirat-radif-in-brand-page dtngjdfjiogdrjiogfyhsei">
            <div class=" style-of-ItemTamirat-div">
               <img class="style-of-ItemTamirat-img" src="img/Lavazem Khanegy Images/DW/1.png"       alt="تعمیر مارکت">
            </div>
            <div class=" style-of-ItemTamirat-div">
               <img class="style-of-ItemTamirat-img" src="img/Lavazem Khanegy Images/DW/2.png"        alt="تعمیر مارکت">
            </div>
            <div class=" style-of-ItemTamirat-div">
                <img class="style-of-ItemTamirat-img" src="img/Lavazem Khanegy Images/DW/3.png"             alt="تعمیر مارکت">
            </div>
            <div class=" style-of-ItemTamirat-div">
                <img class="style-of-ItemTamirat-img" src="img/Lavazem Khanegy Images/DW/4.png"            alt="تعمیر مارکت">
            </div>
            <div class=" style-of-ItemTamirat-div">
                <img class="style-of-ItemTamirat-img" src="img/Lavazem Khanegy Images/DW/8.png"            alt="تعمیر مارکت">
            </div>
        </div>
        <br><br>
        <div class="style-of-ItemTamirat-radif style-of-ItemTamirat-radif-in-brand-page dtngjdfjiogdrjiogfyhsei">
            <div class=" style-of-ItemTamirat-div">
               <img class="style-of-ItemTamirat-img" src="img/Lavazem Khanegy Images/DW/5.png"       alt="تعمیر مارکت">
            </div>
            <div class=" style-of-ItemTamirat-div">
               <img class="style-of-ItemTamirat-img" src="img/Lavazem Khanegy Images/DW/6.png"        alt="تعمیر مارکت">
            </div>
            <div class=" style-of-ItemTamirat-div">
                <img class="style-of-ItemTamirat-img" src="img/Lavazem Khanegy Images/DW/7.png"             alt="تعمیر مارکت">
            </div>
            <div class=" style-of-ItemTamirat-div">
                <img class="style-of-ItemTamirat-img" src="img/Lavazem Khanegy Images/DW/9.png"            alt="تعمیر مارکت">
            </div>
            <div class=" style-of-ItemTamirat-div">
                <img class="style-of-ItemTamirat-img" src="img/Lavazem Khanegy Images/DW/10.png"            alt="تعمیر مارکت">
            </div>
        </div>
    </div>

    <div class="display-none-pc">
        <div class="style-of-ItemTamirat-radif style-of-ItemTamirat-radif-in-brand-page dtngjdfjiogdrjiogfyhsei">
            <div class=" style-of-ItemTamirat-div">
               <img class="style-of-ItemTamirat-img" src="img/Lavazem Khanegy Images/DW/1.png"       alt="تعمیر مارکت">
            </div>
            <div class=" style-of-ItemTamirat-div">
               <img class="style-of-ItemTamirat-img" src="img/Lavazem Khanegy Images/DW/2.png"        alt="تعمیر مارکت">
            </div>
            <div class=" style-of-ItemTamirat-div">
                <img class="style-of-ItemTamirat-img" src="img/Lavazem Khanegy Images/DW/3.png"             alt="تعمیر مارکت">
            </div>
            <div class=" style-of-ItemTamirat-div">
                <img class="style-of-ItemTamirat-img" src="img/Lavazem Khanegy Images/DW/4.png"            alt="تعمیر مارکت">
            </div>
            <div class=" style-of-ItemTamirat-div">
                <img class="style-of-ItemTamirat-img" src="img/Lavazem Khanegy Images/DW/9.png"            alt="تعمیر مارکت">
            </div>
            <div class=" style-of-ItemTamirat-div">
                <img class="style-of-ItemTamirat-img" src="img/Lavazem Khanegy Images/DW/10.png"            alt="تعمیر مارکت">
            </div>
        </div>
        <br><br>
        <div class="style-of-ItemTamirat-radif style-of-ItemTamirat-radif-in-brand-page dtngjdfjiogdrjiogfyhsei">
            <div class=" style-of-ItemTamirat-div">
               <img class="style-of-ItemTamirat-img" src="img/Lavazem Khanegy Images/DW/5.png"       alt="تعمیر مارکت">
            </div>
            <div class=" style-of-ItemTamirat-div">
               <img class="style-of-ItemTamirat-img" src="img/Lavazem Khanegy Images/DW/6.png"        alt="تعمیر مارکت">
            </div>
            <div class=" style-of-ItemTamirat-div">
                <img class="style-of-ItemTamirat-img" src="img/Lavazem Khanegy Images/DW/7.png"             alt="تعمیر مارکت">
            </div>
            <div class=" style-of-ItemTamirat-div">
                <img class="style-of-ItemTamirat-img" src="img/Lavazem Khanegy Images/DW/8.png"            alt="تعمیر مارکت">
            </div>
        </div>
    </div>
    <br><br>
    <table class="style-of-naqshe-iran-box">
        <tr>
            <td>
                <img class="style-of-naqshe-iran-img" src="img/naqshe iran/naqsh iran.png" alt="تعمیر مارکت">
            </td>
            <td>
                <p class="style-of-naqshe-iran-title-text">تعمیر مارکت</p>
                <p class="style-of-naqshe-iran-mini-title-text">محدوده تحت پوشش</p>
                <p class="style-of-naqshe-iran-text">
                    تعمیر مارکت خدمات نصب ، سرویس و تعمیرات لوازم خانگی را در سراسر استان های تهران و البرز(کرج) ارائه می نماید .از نواحی تحت پوشش این مجموعه میتوان به شهر های تهران ، کرج ، هشتگرد و... اشاره نمود .
                </p>
            </td>
        </tr>
    </table>
    <table class="style-of-naqshe-iran-box-mo">
        <tr>
            <td>
                <img class="style-of-naqshe-iran-img" src="img/naqshe iran/naqsh iran.png" alt="تعمیر مارکت">
            </td>
        </tr>
        <tr>
            <td>
                <p class="style-of-naqshe-iran-title-text">تعمیر مارکت</p>
                <p class="style-of-naqshe-iran-mini-title-text">محدوده تحت پوشش</p>
                <p class="style-of-naqshe-iran-text">
                    تعمیر مارکت خدمات نصب ، سرویس و تعمیرات لوازم خانگی را در سراسر استان های تهران و البرز(کرج) ارائه می نماید .از نواحی تحت پوشش این مجموعه میتوان به شهر های تهران ، کرج ، هشتگرد و... اشاره نمود .
                </p>
            </td>
        </tr>
    </table>
    <br><br>
    
    <!-- ---------------------------------------------------------------------------------------------------- -->
    <!-- new-news -->
    <p class="style-of-new-news">
        جدید ترین مطالب آموزشی سرویس و تعمیرات لوازم خانگی
    </p>
<table class="style-of-new-news-table-box">
    <tr class="style-of-new-news-tr">
        <td class="style-of-new-news-td">
            <img class="style-of-new-news-img" src="img/new news/1.png" alt="تعمیر مارکت">
        </td>
        <td class="style-of-new-news-td">
            <img class="style-of-new-news-img" src="img/new news/2.png" alt="تعمیر مارکت">
        </td>
        <td class="style-of-new-news-td">
            <img class="style-of-new-news-img" src="img/new news/3.png" alt="تعمیر مارکت">
        </td>
        <td class="style-of-new-news-td">
            <img class="style-of-new-news-img" src="img/new news/4.png" alt="تعمیر مارکت">
        </td>
        <td class="style-of-new-news-td">
            <img class="style-of-new-news-img" src="img/new news/8.png" alt="تعمیر مارکت">
        </td>
    </tr>
    <tr>
        <td class="style-of-new-news-td">
            <img class="style-of-new-news-img" src="img/new news/5.png" alt="تعمیر مارکت">
        </td>
        <td class="style-of-new-news-td">
            <img class="style-of-new-news-img" src="img/new news/6.png" alt="تعمیر مارکت">
        </td>
        <td class="style-of-new-news-td">
            <img class="style-of-new-news-img" src="img/new news/7.png" alt="تعمیر مارکت">
        </td>
        <td class="style-of-new-news-td">
            <img class="style-of-new-news-img" src="img/new news/8.png" alt="تعمیر مارکت">
        </td>
        <td class="style-of-new-news-td">
            <img class="style-of-new-news-img" src="img/new news/7.png" alt="تعمیر مارکت">
        </td>

    </tr>
</table>
<table class="style-of-new-news-table-box-mo">
    <tr class="style-of-new-news-tr">
        <td class="style-of-new-news-td">
            <img class="style-of-new-news-img" src="img/new news/1.png" alt="تعمیر مارکت">
        </td>
        <td class="style-of-new-news-td">
            <img class="style-of-new-news-img" src="img/new news/2.png" alt="تعمیر مارکت">
        </td>
    </tr>
    <tr class="style-of-new-news-tr">
        <td class="style-of-new-news-td">
            <img class="style-of-new-news-img" src="img/new news/3.png" alt="تعمیر مارکت">
        </td>
        <td class="style-of-new-news-td">
            <img class="style-of-new-news-img" src="img/new news/4.png" alt="تعمیر مارکت">
        </td>
    </tr>
    <tr class="style-of-new-news-tr">
        <td class="style-of-new-news-td">
            <img class="style-of-new-news-img" src="img/new news/5.png" alt="تعمیر مارکت">
        </td>
        <td class="style-of-new-news-td">
            <img class="style-of-new-news-img" src="img/new news/6.png" alt="تعمیر مارکت">
        </td>
    </tr>
    <tr class="style-of-new-news-tr">
        <td class="style-of-new-news-td">
            <img class="style-of-new-news-img" src="img/new news/7.png" alt="تعمیر مارکت">
        </td>
        <td class="style-of-new-news-td">
            <img class="style-of-new-news-img" src="img/new news/8.png" alt="تعمیر مارکت">
        </td>
    </tr>
    <tr class="style-of-new-news-tr">
        <td class="style-of-new-news-td">
            <img class="style-of-new-news-img" src="img/new news/7.png" alt="تعمیر مارکت">
        </td>
        <td class="style-of-new-news-td">
            <img class="style-of-new-news-img" src="img/new news/8.png" alt="تعمیر مارکت">
        </td>
    </tr>
</table>
<!-- ---------------------------------------------------------------------------------------------------- -->
<!-- *** footer *** -->
<table class="style-of-footer-title display-none-mo">
    <tr>
        <td class="style-of-footer-td">
            <p class="style-of-footer-asli-title"><span class="text-color-darkblue-2">تعمیرات لوازم خانگی  
            <br> 
            تعمیر مارکت</span></p>
        </td>
        <td class="style-of-footer-td">
            <p class="style-of-footer-title">استان تهران</p>
        </td>
        <td class="style-of-footer-td">
            <p class="style-of-footer-title">استان البرز (کرج)</p>  
        </td>
    </tr>
    <tr>
        <td rowspan="2" class="style-of-footer-td">
            <img class="style-of-footer-logo" src="img/footer/footerlogo.png" alt="ارتباط با ما | تعمیر مارکت">
        </td>
        <td class="style-of-footer-td">
                <p class="style-of-footer-title">۰۹۱۲-۳۲۰۲۰۱۳</p>  
        </td>
        <td class="style-of-footer-td">
                <p class="style-of-footer-title">۰۲۶-۳۴۲۱۳۹۸۵</p>  
        </td>
    </tr>
    <tr>
        <td class="style-of-footer-td">
                <p class="style-of-footer-title">۰۹۱۲-۹۲۴۲۷۷۶</p>  
        </td>
        <td class="style-of-footer-td">
                <p class="style-of-footer-title">۰۲۶-۳۴۲۱۳۸۴۹</p>  
        </td>
    </tr>
    <tr>
        <td class="style-of-footer-td"> 
        <p class="style-of-footer-copyright">
                تمامی حقوق برای تعمیر مارکت محفوظ می باشد ©
        </p>
        </td>
        <td class="style-of-footer-td">
            <a class="style-of-footer-a">
                <p class="style-of-footer-title">۰۹۱۲-۹۲۴۲۷۸۱</p>  
            </a>
        </td>
        <td class="style-of-footer-td">
            <p class="style-of-footer-address">
                کرج، بلوار امام خمینی، نرسیده به دانشگاه رسام، ساختمان سپاس
            </p>  
        </td>
    </tr>
    </table>    













    <table class="style-of-footer-title display-none-pc">
    <tr>
    <td class="style-of-footer-td">
         <p class="style-of-footer-asli-title"><span class="text-color-darkblue-2">تعمیر مارکت</span></p>
    </td>
    </tr>
    <tr>
    <td class="style-of-footer-td">
        <img class="style-of-footer-logo" src="img/footer/footerlogo.png" alt="ارتباط با ما | تعمیر مارکت">
    </td>
    </tr>
    <tr>
        <td class="style-of-footer-td">
            <p class="style-of-footer-title">استان تهران</p>
        </td>
    </tr>
    <tr>
        <td class="style-of-footer-td">
            <a class="style-of-footer-a">
                <p class="style-of-footer-title">۰۹۱۲-۳۲۰۲۰۱۳ - ۰۹۱۲-۲۲۴۶۰۴۶</p>  
            </a>
        </td>
    </tr>
    <tr>
    
    </tr>
    <tr>
        <td class="style-of-footer-td">
            <a class="style-of-footer-a">
                <p class="style-of-footer-title">۰۹۱۲-۰۴۵۷۹۶۹ - ۰۹۱۲-۹۲۴۲۷۸۱</p>  
            </a>
        </td>
    </tr>
     
    </tr>
    <tr>
        <td class="style-of-footer-td">
            <p class="style-of-footer-title">استان البرز (کرج)</p>  
        </td>
    </tr>
    <tr>
        <td class="style-of-footer-td">
            <a class="style-of-footer-a">
                <p class="style-of-footer-title">۰۲۶-۳۴۲۱۳۹۸۵ - ۰۲۶-۳۴۲۱۳۸۴۹</p>  
            </a>
        </td>
    </tr>
    <tr>
        <td class="style-of-footer-td">
            <a class="style-of-footer-a">
                <p class="style-of-footer-title">۰۹۱۲-۹۲۴۲۷۷۶</p>  
            </a>
        </td>
    </tr>
    <tr>
        <td class="style-of-footer-td">
            <p class="style-of-footer-address">
                آدرس:
                کرج، خیابان شهید بهشتی، بلوار امام خمینی، نرسیده به دانشگاه رسام، ساختمان سپاس
            </p>  
        </td>
    </tr>
    <tr>
        <td class="style-of-footer-td">
            <p class="style-of-footer-copyright">
                تمامی حقوق برای تعمیر مارکت محفوظ می باشد ©
            </p>
        </td>
    </tr>
    <tr>
        <td class="style-of-footer-td"> 
            <a class="style-of-footer-made-by-ITROSOFT"  href="#">
                <p class="style-of-footer-made-by-ITROSOFT">ساخته شده توسط Itro Programming</p>
            </a>
        </td>
    </tr>
    </table>
    <!-- end *** footer *** -->
    <!-- ---------------------------------------------------------------------------------------------------- -->

<h1 class="style-pf-secret-key-words"> ارج - تعمیر - تعمیرات - رفع - ایراد - ایرادات - مشکل - وسیله ی مورد نظر - ماشین - دوقلو - درب - از - بالا - در - استان - تهران - البرز - کرج - خشک - کن - دار-اتوماتیک - تعمیر مارکت - تعمیرگاه - خدمات - مجاز - مرکزی - سرویس - نصب - جاده - چالوس - زنبق -عظیمیه -بعثت - طالقانی - شمالی - طالقانی - جنوبی - میدان - اسبی - میدان - مهران - بلوار - کاج - پامچال - شمالی - پامچال - جنوبی - برغان - اسلام - اباد - آباد - ازادگان - آزادگان - حسن - اباد- آباد - نواب - مطهری - میدان - نبوت - بلوار - جمهوری - شمالی - بلوار - جمهوری - جنوبی - بلوار - موذن - اشتراکی - شمالی - اشتراکی - جنوبی - کوی - پیروزی - شهرک - بهارستان - ملکشاه - بلوار - امام - رضا - بلوار - ملاصدرا - ملا صدرا - جهانشهر - کسری - شمالی - کسری - جنوبی - بلوار - ماهان - بلوار - بهارستان - فرمانداری - رجایی - شهر - گوهر - دشت - بلوار - رستاخیز - بلوار - شهرداری - بلوار - انقلاب - اوقافی - محمود - اباد - باغستان - باغستان - غربی - خیابان - قلم - بنیاد - شاهین - ویلا - جواد - اباد - کوی - داریوش - شهرک - یاس - حصارک - بالا - حصارک - پایین - کمال - اباد - خرمدشت - پیشاهنگی - نظر - اباد - هشتگرد - شهرک - رازی - مهر - شهر- بلوار - ارم - حسین - اباد - مهرشهر - کیانمهر - فاز - 4 - مهر - شهر - 45 -متری - گلشهر - شهرک - مترو- شهرک - پردیسان - شهرک - سلمان - فارسی - دهقان - ویلای - اول - دهقان - ویلای - دوم - میانجاده - حیدر - اباد - کرج - نو - سه - راه - گوهر - دشت - بلوار - سه - باندی - کوی - داریوش - زمین - های - خانم - انصاری - کوی - کارمندان - شمالی - کوی - کارمندان - جنوبی - مهر - ویلا - بلوار - دانش - اموز - دولت - اباد - چهار - صد - دستگاه - هفت - تیر - محمد - شهر - شهرک - مهندسی - زراعی - فردیس - شهرک - وحدت - شهرک - منظریه - ساسانی - فردوسی - رزکان - نو - قلمستان - مصباح - کلاک - بالا - کلاک - پایین - کلاک -  شهرداری - گرمدره - شهرک - جهان - نما - شهرک - خاتم - حسین - آباد - راهن - راه - آهن - اهن - جاده - چالوس - زنبق - عظیمیه - بعثت - طالقانی - شمالی - طالقانی - جنوبی - میدان - اسبی - میدان - مهران - بلوار - کاج - پامچال - شمالی - پامچال - جنوبی - برغان - اسلام - اباد - ازادگان - حسن - اباد - نواب - مطهری - میدان - نبوت - بلوار - جمهوری - شمالی - بلوار - جمهوری - جنوبی - بلوار - موذن - اشتراکی - شمالی - اشتراکی - جنوبی - کوی - پیروزی - شهرک - بهارستان - ملکشاه - بلوار - امام - رضا - بلوار - ملا - صدرا - ملاصدرا - جهانشهر - کسری - شمالی - کسری - جنوبی - بلوار - ماهان - بلوار - بهارستان - فرمانداری - رجایی - شهر - گوهر - دشت - بلوار - رستاخیز - بلوار - شهرداری - بلوار - انقلاب - اوقافی - محمود - اباد - باغستان - باغستان - غربی - خیابان - قلم - بنیاد - شاهین - ویلا - جواد - اباد - کوی - داریوش - شهرک - یاس - حصارک - بالا - حصارک - پایین - کمال - اباد - خرمدشت - پیشاهنگی - نظر - اباد - هشتگرد - شهرک - رازی - مهر - شهر - بلوار - ارم - حسین - اباد - مهر - شهر - کیانمهر - کیان - مهر - فاز - چهار - 4 - مهر - شهر - 45متری - چهل - و- پنج - متری - گلشهر - شهرک - مترو - شهرک - پردیسان - شهرک - سلمان - فارسی - دهقان - ویلای - اول - دهقان - ویلای - دوم - میانجاده - حیدر - اباد - کرج - نو - سه - راه - گوهر - دشت - بلوار - سه - باندی - کوی - داریوش - زمین - های - خانم - انصاری - کوی - کارمندان - شمالی - کوی - کارمندان - جنوبی - مهر - ویلا - بلوار - دانش - اموز - آموز - دولت - اباد - چهار - صد - دستگاه - هفت - تیر - محمد - شهر - شهرک - مهندسی - زراعی - فردیس - شهرک - وحدت - شهرک - منظریه - ساسانی - فردوسی - رزکان - نو - قلمستان - مصباح - کلاک - بالا - کلاک -پایین - کلاک - شهرداری - گرمدره - شهرک - جهان - نما - شهرک - خاتم - حسین - آباد - راهن - منیریه - گمرک - نازی‌ - آباد - خانی‌ - آباد - خزانه - کیان‌ - شهر - بریانک - پیروزی - نیرو - هوایی - صفا - افسریه - بهارستان - دروازه - شمیران - شکوفه - مشیریه - شهر - ری - نازی - آباد - میدان - خراسان - خاوران - سعادت - آباد - شهرک - غرب - پونک - جی - باغ فیض - شهران - ستارخان - صادقیه - گیشا - اکباتان - سردار - جنگل - کاشانی - المپیک - آزادی - درکه - تهرانسر - شهرآرا - شهرزیبا - مرزداران - فردوس - اوین - ایوانک - نیاوران - دزاشیب - پاسداران - فرمانیه - ازگل - ارتش - تجریش - زعفرانیه - قیطریه - چیذر - اختیاریه - قلهک - ظفر - میرداماد - جردن - نوبنیاد - نو بنیاد - شریعتی - هفت تیر - یوسف آباد - سهروردی - وزرا - الهیه - گاندی - تهرانپارس - حکیمیه - رسالت - هفت - حوض - سراج - دلاوران - شمیران - نو - هنگام - نارمک - مجیدیه - بهار - سبلان - دردشت - نظام - آباد - علم - و - صنعت - پیروزی - پلیس - کرمان - مدنی - امام - حسین - تهران - نو</h1>
<h2 class="style-pf-secret-key-words"> ارج - تعمیر - تعمیرات - رفع - ایراد - ایرادات - مشکل - وسیله ی مورد نظر - ماشین - دوقلو - درب - از - بالا - در - استان - تهران - البرز - کرج - خشک - کن - دار-اتوماتیک - تعمیر مارکت - تعمیرگاه - خدمات - مجاز - مرکزی - سرویس - نصب - جاده - چالوس - زنبق -عظیمیه -بعثت - طالقانی - شمالی - طالقانی - جنوبی - میدان - اسبی - میدان - مهران - بلوار - کاج - پامچال - شمالی - پامچال - جنوبی - برغان - اسلام - اباد - آباد - ازادگان - آزادگان - حسن - اباد- آباد - نواب - مطهری - میدان - نبوت - بلوار - جمهوری - شمالی - بلوار - جمهوری - جنوبی - بلوار - موذن - اشتراکی - شمالی - اشتراکی - جنوبی - کوی - پیروزی - شهرک - بهارستان - ملکشاه - بلوار - امام - رضا - بلوار - ملاصدرا - ملا صدرا - جهانشهر - کسری - شمالی - کسری - جنوبی - بلوار - ماهان - بلوار - بهارستان - فرمانداری - رجایی - شهر - گوهر - دشت - بلوار - رستاخیز - بلوار - شهرداری - بلوار - انقلاب - اوقافی - محمود - اباد - باغستان - باغستان - غربی - خیابان - قلم - بنیاد - شاهین - ویلا - جواد - اباد - کوی - داریوش - شهرک - یاس - حصارک - بالا - حصارک - پایین - کمال - اباد - خرمدشت - پیشاهنگی - نظر - اباد - هشتگرد - شهرک - رازی - مهر - شهر- بلوار - ارم - حسین - اباد - مهرشهر - کیانمهر - فاز - 4 - مهر - شهر - 45 -متری - گلشهر - شهرک - مترو- شهرک - پردیسان - شهرک - سلمان - فارسی - دهقان - ویلای - اول - دهقان - ویلای - دوم - میانجاده - حیدر - اباد - کرج - نو - سه - راه - گوهر - دشت - بلوار - سه - باندی - کوی - داریوش - زمین - های - خانم - انصاری - کوی - کارمندان - شمالی - کوی - کارمندان - جنوبی - مهر - ویلا - بلوار - دانش - اموز - دولت - اباد - چهار - صد - دستگاه - هفت - تیر - محمد - شهر - شهرک - مهندسی - زراعی - فردیس - شهرک - وحدت - شهرک - منظریه - ساسانی - فردوسی - رزکان - نو - قلمستان - مصباح - کلاک - بالا - کلاک - پایین - کلاک -  شهرداری - گرمدره - شهرک - جهان - نما - شهرک - خاتم - حسین - آباد - راهن - راه - آهن - اهن - جاده - چالوس - زنبق - عظیمیه - بعثت - طالقانی - شمالی - طالقانی - جنوبی - میدان - اسبی - میدان - مهران - بلوار - کاج - پامچال - شمالی - پامچال - جنوبی - برغان - اسلام - اباد - ازادگان - حسن - اباد - نواب - مطهری - میدان - نبوت - بلوار - جمهوری - شمالی - بلوار - جمهوری - جنوبی - بلوار - موذن - اشتراکی - شمالی - اشتراکی - جنوبی - کوی - پیروزی - شهرک - بهارستان - ملکشاه - بلوار - امام - رضا - بلوار - ملا - صدرا - ملاصدرا - جهانشهر - کسری - شمالی - کسری - جنوبی - بلوار - ماهان - بلوار - بهارستان - فرمانداری - رجایی - شهر - گوهر - دشت - بلوار - رستاخیز - بلوار - شهرداری - بلوار - انقلاب - اوقافی - محمود - اباد - باغستان - باغستان - غربی - خیابان - قلم - بنیاد - شاهین - ویلا - جواد - اباد - کوی - داریوش - شهرک - یاس - حصارک - بالا - حصارک - پایین - کمال - اباد - خرمدشت - پیشاهنگی - نظر - اباد - هشتگرد - شهرک - رازی - مهر - شهر - بلوار - ارم - حسین - اباد - مهر - شهر - کیانمهر - کیان - مهر - فاز - چهار - 4 - مهر - شهر - 45متری - چهل - و- پنج - متری - گلشهر - شهرک - مترو - شهرک - پردیسان - شهرک - سلمان - فارسی - دهقان - ویلای - اول - دهقان - ویلای - دوم - میانجاده - حیدر - اباد - کرج - نو - سه - راه - گوهر - دشت - بلوار - سه - باندی - کوی - داریوش - زمین - های - خانم - انصاری - کوی - کارمندان - شمالی - کوی - کارمندان - جنوبی - مهر - ویلا - بلوار - دانش - اموز - آموز - دولت - اباد - چهار - صد - دستگاه - هفت - تیر - محمد - شهر - شهرک - مهندسی - زراعی - فردیس - شهرک - وحدت - شهرک - منظریه - ساسانی - فردوسی - رزکان - نو - قلمستان - مصباح - کلاک - بالا - کلاک -پایین - کلاک - شهرداری - گرمدره - شهرک - جهان - نما - شهرک - خاتم - حسین - آباد - راهن - منیریه - گمرک - نازی‌ - آباد - خانی‌ - آباد - خزانه - کیان‌ - شهر - بریانک - پیروزی - نیرو - هوایی - صفا - افسریه - بهارستان - دروازه - شمیران - شکوفه - مشیریه - شهر - ری - نازی - آباد - میدان - خراسان - خاوران - سعادت - آباد - شهرک - غرب - پونک - جی - باغ فیض - شهران - ستارخان - صادقیه - گیشا - اکباتان - سردار - جنگل - کاشانی - المپیک - آزادی - درکه - تهرانسر - شهرآرا - شهرزیبا - مرزداران - فردوس - اوین - ایوانک - نیاوران - دزاشیب - پاسداران - فرمانیه - ازگل - ارتش - تجریش - زعفرانیه - قیطریه - چیذر - اختیاریه - قلهک - ظفر - میرداماد - جردن - نوبنیاد - نو بنیاد - شریعتی - هفت تیر - یوسف آباد - سهروردی - وزرا - الهیه - گاندی - تهرانپارس - حکیمیه - رسالت - هفت - حوض - سراج - دلاوران - شمیران - نو - هنگام - نارمک - مجیدیه - بهار - سبلان - دردشت - نظام - آباد - علم - و - صنعت - پیروزی - پلیس - کرمان - مدنی - امام - حسین - تهران - نو</h2>
<h3 class="style-pf-secret-key-words"> ارج - تعمیر - تعمیرات - رفع - ایراد - ایرادات - مشکل - وسیله ی مورد نظر - ماشین - دوقلو - درب - از - بالا - در - استان - تهران - البرز - کرج - خشک - کن - دار-اتوماتیک - تعمیر مارکت - تعمیرگاه - خدمات - مجاز - مرکزی - سرویس - نصب - جاده - چالوس - زنبق -عظیمیه -بعثت - طالقانی - شمالی - طالقانی - جنوبی - میدان - اسبی - میدان - مهران - بلوار - کاج - پامچال - شمالی - پامچال - جنوبی - برغان - اسلام - اباد - آباد - ازادگان - آزادگان - حسن - اباد- آباد - نواب - مطهری - میدان - نبوت - بلوار - جمهوری - شمالی - بلوار - جمهوری - جنوبی - بلوار - موذن - اشتراکی - شمالی - اشتراکی - جنوبی - کوی - پیروزی - شهرک - بهارستان - ملکشاه - بلوار - امام - رضا - بلوار - ملاصدرا - ملا صدرا - جهانشهر - کسری - شمالی - کسری - جنوبی - بلوار - ماهان - بلوار - بهارستان - فرمانداری - رجایی - شهر - گوهر - دشت - بلوار - رستاخیز - بلوار - شهرداری - بلوار - انقلاب - اوقافی - محمود - اباد - باغستان - باغستان - غربی - خیابان - قلم - بنیاد - شاهین - ویلا - جواد - اباد - کوی - داریوش - شهرک - یاس - حصارک - بالا - حصارک - پایین - کمال - اباد - خرمدشت - پیشاهنگی - نظر - اباد - هشتگرد - شهرک - رازی - مهر - شهر- بلوار - ارم - حسین - اباد - مهرشهر - کیانمهر - فاز - 4 - مهر - شهر - 45 -متری - گلشهر - شهرک - مترو- شهرک - پردیسان - شهرک - سلمان - فارسی - دهقان - ویلای - اول - دهقان - ویلای - دوم - میانجاده - حیدر - اباد - کرج - نو - سه - راه - گوهر - دشت - بلوار - سه - باندی - کوی - داریوش - زمین - های - خانم - انصاری - کوی - کارمندان - شمالی - کوی - کارمندان - جنوبی - مهر - ویلا - بلوار - دانش - اموز - دولت - اباد - چهار - صد - دستگاه - هفت - تیر - محمد - شهر - شهرک - مهندسی - زراعی - فردیس - شهرک - وحدت - شهرک - منظریه - ساسانی - فردوسی - رزکان - نو - قلمستان - مصباح - کلاک - بالا - کلاک - پایین - کلاک -  شهرداری - گرمدره - شهرک - جهان - نما - شهرک - خاتم - حسین - آباد - راهن - راه - آهن - اهن - جاده - چالوس - زنبق - عظیمیه - بعثت - طالقانی - شمالی - طالقانی - جنوبی - میدان - اسبی - میدان - مهران - بلوار - کاج - پامچال - شمالی - پامچال - جنوبی - برغان - اسلام - اباد - ازادگان - حسن - اباد - نواب - مطهری - میدان - نبوت - بلوار - جمهوری - شمالی - بلوار - جمهوری - جنوبی - بلوار - موذن - اشتراکی - شمالی - اشتراکی - جنوبی - کوی - پیروزی - شهرک - بهارستان - ملکشاه - بلوار - امام - رضا - بلوار - ملا - صدرا - ملاصدرا - جهانشهر - کسری - شمالی - کسری - جنوبی - بلوار - ماهان - بلوار - بهارستان - فرمانداری - رجایی - شهر - گوهر - دشت - بلوار - رستاخیز - بلوار - شهرداری - بلوار - انقلاب - اوقافی - محمود - اباد - باغستان - باغستان - غربی - خیابان - قلم - بنیاد - شاهین - ویلا - جواد - اباد - کوی - داریوش - شهرک - یاس - حصارک - بالا - حصارک - پایین - کمال - اباد - خرمدشت - پیشاهنگی - نظر - اباد - هشتگرد - شهرک - رازی - مهر - شهر - بلوار - ارم - حسین - اباد - مهر - شهر - کیانمهر - کیان - مهر - فاز - چهار - 4 - مهر - شهر - 45متری - چهل - و- پنج - متری - گلشهر - شهرک - مترو - شهرک - پردیسان - شهرک - سلمان - فارسی - دهقان - ویلای - اول - دهقان - ویلای - دوم - میانجاده - حیدر - اباد - کرج - نو - سه - راه - گوهر - دشت - بلوار - سه - باندی - کوی - داریوش - زمین - های - خانم - انصاری - کوی - کارمندان - شمالی - کوی - کارمندان - جنوبی - مهر - ویلا - بلوار - دانش - اموز - آموز - دولت - اباد - چهار - صد - دستگاه - هفت - تیر - محمد - شهر - شهرک - مهندسی - زراعی - فردیس - شهرک - وحدت - شهرک - منظریه - ساسانی - فردوسی - رزکان - نو - قلمستان - مصباح - کلاک - بالا - کلاک -پایین - کلاک - شهرداری - گرمدره - شهرک - جهان - نما - شهرک - خاتم - حسین - آباد - راهن - منیریه - گمرک - نازی‌ - آباد - خانی‌ - آباد - خزانه - کیان‌ - شهر - بریانک - پیروزی - نیرو - هوایی - صفا - افسریه - بهارستان - دروازه - شمیران - شکوفه - مشیریه - شهر - ری - نازی - آباد - میدان - خراسان - خاوران - سعادت - آباد - شهرک - غرب - پونک - جی - باغ فیض - شهران - ستارخان - صادقیه - گیشا - اکباتان - سردار - جنگل - کاشانی - المپیک - آزادی - درکه - تهرانسر - شهرآرا - شهرزیبا - مرزداران - فردوس - اوین - ایوانک - نیاوران - دزاشیب - پاسداران - فرمانیه - ازگل - ارتش - تجریش - زعفرانیه - قیطریه - چیذر - اختیاریه - قلهک - ظفر - میرداماد - جردن - نوبنیاد - نو بنیاد - شریعتی - هفت تیر - یوسف آباد - سهروردی - وزرا - الهیه - گاندی - تهرانپارس - حکیمیه - رسالت - هفت - حوض - سراج - دلاوران - شمیران - نو - هنگام - نارمک - مجیدیه - بهار - سبلان - دردشت - نظام - آباد - علم - و - صنعت - پیروزی - پلیس - کرمان - مدنی - امام - حسین - تهران - نو</h3>
<h4 class="style-pf-secret-key-words"> ارج - تعمیر - تعمیرات - رفع - ایراد - ایرادات - مشکل - وسیله ی مورد نظر - ماشین - دوقلو - درب - از - بالا - در - استان - تهران - البرز - کرج - خشک - کن - دار-اتوماتیک - تعمیر مارکت - تعمیرگاه - خدمات - مجاز - مرکزی - سرویس - نصب - جاده - چالوس - زنبق -عظیمیه -بعثت - طالقانی - شمالی - طالقانی - جنوبی - میدان - اسبی - میدان - مهران - بلوار - کاج - پامچال - شمالی - پامچال - جنوبی - برغان - اسلام - اباد - آباد - ازادگان - آزادگان - حسن - اباد- آباد - نواب - مطهری - میدان - نبوت - بلوار - جمهوری - شمالی - بلوار - جمهوری - جنوبی - بلوار - موذن - اشتراکی - شمالی - اشتراکی - جنوبی - کوی - پیروزی - شهرک - بهارستان - ملکشاه - بلوار - امام - رضا - بلوار - ملاصدرا - ملا صدرا - جهانشهر - کسری - شمالی - کسری - جنوبی - بلوار - ماهان - بلوار - بهارستان - فرمانداری - رجایی - شهر - گوهر - دشت - بلوار - رستاخیز - بلوار - شهرداری - بلوار - انقلاب - اوقافی - محمود - اباد - باغستان - باغستان - غربی - خیابان - قلم - بنیاد - شاهین - ویلا - جواد - اباد - کوی - داریوش - شهرک - یاس - حصارک - بالا - حصارک - پایین - کمال - اباد - خرمدشت - پیشاهنگی - نظر - اباد - هشتگرد - شهرک - رازی - مهر - شهر- بلوار - ارم - حسین - اباد - مهرشهر - کیانمهر - فاز - 4 - مهر - شهر - 45 -متری - گلشهر - شهرک - مترو- شهرک - پردیسان - شهرک - سلمان - فارسی - دهقان - ویلای - اول - دهقان - ویلای - دوم - میانجاده - حیدر - اباد - کرج - نو - سه - راه - گوهر - دشت - بلوار - سه - باندی - کوی - داریوش - زمین - های - خانم - انصاری - کوی - کارمندان - شمالی - کوی - کارمندان - جنوبی - مهر - ویلا - بلوار - دانش - اموز - دولت - اباد - چهار - صد - دستگاه - هفت - تیر - محمد - شهر - شهرک - مهندسی - زراعی - فردیس - شهرک - وحدت - شهرک - منظریه - ساسانی - فردوسی - رزکان - نو - قلمستان - مصباح - کلاک - بالا - کلاک - پایین - کلاک -  شهرداری - گرمدره - شهرک - جهان - نما - شهرک - خاتم - حسین - آباد - راهن - راه - آهن - اهن - جاده - چالوس - زنبق - عظیمیه - بعثت - طالقانی - شمالی - طالقانی - جنوبی - میدان - اسبی - میدان - مهران - بلوار - کاج - پامچال - شمالی - پامچال - جنوبی - برغان - اسلام - اباد - ازادگان - حسن - اباد - نواب - مطهری - میدان - نبوت - بلوار - جمهوری - شمالی - بلوار - جمهوری - جنوبی - بلوار - موذن - اشتراکی - شمالی - اشتراکی - جنوبی - کوی - پیروزی - شهرک - بهارستان - ملکشاه - بلوار - امام - رضا - بلوار - ملا - صدرا - ملاصدرا - جهانشهر - کسری - شمالی - کسری - جنوبی - بلوار - ماهان - بلوار - بهارستان - فرمانداری - رجایی - شهر - گوهر - دشت - بلوار - رستاخیز - بلوار - شهرداری - بلوار - انقلاب - اوقافی - محمود - اباد - باغستان - باغستان - غربی - خیابان - قلم - بنیاد - شاهین - ویلا - جواد - اباد - کوی - داریوش - شهرک - یاس - حصارک - بالا - حصارک - پایین - کمال - اباد - خرمدشت - پیشاهنگی - نظر - اباد - هشتگرد - شهرک - رازی - مهر - شهر - بلوار - ارم - حسین - اباد - مهر - شهر - کیانمهر - کیان - مهر - فاز - چهار - 4 - مهر - شهر - 45متری - چهل - و- پنج - متری - گلشهر - شهرک - مترو - شهرک - پردیسان - شهرک - سلمان - فارسی - دهقان - ویلای - اول - دهقان - ویلای - دوم - میانجاده - حیدر - اباد - کرج - نو - سه - راه - گوهر - دشت - بلوار - سه - باندی - کوی - داریوش - زمین - های - خانم - انصاری - کوی - کارمندان - شمالی - کوی - کارمندان - جنوبی - مهر - ویلا - بلوار - دانش - اموز - آموز - دولت - اباد - چهار - صد - دستگاه - هفت - تیر - محمد - شهر - شهرک - مهندسی - زراعی - فردیس - شهرک - وحدت - شهرک - منظریه - ساسانی - فردوسی - رزکان - نو - قلمستان - مصباح - کلاک - بالا - کلاک -پایین - کلاک - شهرداری - گرمدره - شهرک - جهان - نما - شهرک - خاتم - حسین - آباد - راهن - منیریه - گمرک - نازی‌ - آباد - خانی‌ - آباد - خزانه - کیان‌ - شهر - بریانک - پیروزی - نیرو - هوایی - صفا - افسریه - بهارستان - دروازه - شمیران - شکوفه - مشیریه - شهر - ری - نازی - آباد - میدان - خراسان - خاوران - سعادت - آباد - شهرک - غرب - پونک - جی - باغ فیض - شهران - ستارخان - صادقیه - گیشا - اکباتان - سردار - جنگل - کاشانی - المپیک - آزادی - درکه - تهرانسر - شهرآرا - شهرزیبا - مرزداران - فردوس - اوین - ایوانک - نیاوران - دزاشیب - پاسداران - فرمانیه - ازگل - ارتش - تجریش - زعفرانیه - قیطریه - چیذر - اختیاریه - قلهک - ظفر - میرداماد - جردن - نوبنیاد - نو بنیاد - شریعتی - هفت تیر - یوسف آباد - سهروردی - وزرا - الهیه - گاندی - تهرانپارس - حکیمیه - رسالت - هفت - حوض - سراج - دلاوران - شمیران - نو - هنگام - نارمک - مجیدیه - بهار - سبلان - دردشت - نظام - آباد - علم - و - صنعت - پیروزی - پلیس - کرمان - مدنی - امام - حسین - تهران - نو</h4>
<h5 class="style-pf-secret-key-words"> ارج - تعمیر - تعمیرات - رفع - ایراد - ایرادات - مشکل - وسیله ی مورد نظر - ماشین - دوقلو - درب - از - بالا - در - استان - تهران - البرز - کرج - خشک - کن - دار-اتوماتیک - تعمیر مارکت - تعمیرگاه - خدمات - مجاز - مرکزی - سرویس - نصب - جاده - چالوس - زنبق -عظیمیه -بعثت - طالقانی - شمالی - طالقانی - جنوبی - میدان - اسبی - میدان - مهران - بلوار - کاج - پامچال - شمالی - پامچال - جنوبی - برغان - اسلام - اباد - آباد - ازادگان - آزادگان - حسن - اباد- آباد - نواب - مطهری - میدان - نبوت - بلوار - جمهوری - شمالی - بلوار - جمهوری - جنوبی - بلوار - موذن - اشتراکی - شمالی - اشتراکی - جنوبی - کوی - پیروزی - شهرک - بهارستان - ملکشاه - بلوار - امام - رضا - بلوار - ملاصدرا - ملا صدرا - جهانشهر - کسری - شمالی - کسری - جنوبی - بلوار - ماهان - بلوار - بهارستان - فرمانداری - رجایی - شهر - گوهر - دشت - بلوار - رستاخیز - بلوار - شهرداری - بلوار - انقلاب - اوقافی - محمود - اباد - باغستان - باغستان - غربی - خیابان - قلم - بنیاد - شاهین - ویلا - جواد - اباد - کوی - داریوش - شهرک - یاس - حصارک - بالا - حصارک - پایین - کمال - اباد - خرمدشت - پیشاهنگی - نظر - اباد - هشتگرد - شهرک - رازی - مهر - شهر- بلوار - ارم - حسین - اباد - مهرشهر - کیانمهر - فاز - 4 - مهر - شهر - 45 -متری - گلشهر - شهرک - مترو- شهرک - پردیسان - شهرک - سلمان - فارسی - دهقان - ویلای - اول - دهقان - ویلای - دوم - میانجاده - حیدر - اباد - کرج - نو - سه - راه - گوهر - دشت - بلوار - سه - باندی - کوی - داریوش - زمین - های - خانم - انصاری - کوی - کارمندان - شمالی - کوی - کارمندان - جنوبی - مهر - ویلا - بلوار - دانش - اموز - دولت - اباد - چهار - صد - دستگاه - هفت - تیر - محمد - شهر - شهرک - مهندسی - زراعی - فردیس - شهرک - وحدت - شهرک - منظریه - ساسانی - فردوسی - رزکان - نو - قلمستان - مصباح - کلاک - بالا - کلاک - پایین - کلاک -  شهرداری - گرمدره - شهرک - جهان - نما - شهرک - خاتم - حسین - آباد - راهن - راه - آهن - اهن - جاده - چالوس - زنبق - عظیمیه - بعثت - طالقانی - شمالی - طالقانی - جنوبی - میدان - اسبی - میدان - مهران - بلوار - کاج - پامچال - شمالی - پامچال - جنوبی - برغان - اسلام - اباد - ازادگان - حسن - اباد - نواب - مطهری - میدان - نبوت - بلوار - جمهوری - شمالی - بلوار - جمهوری - جنوبی - بلوار - موذن - اشتراکی - شمالی - اشتراکی - جنوبی - کوی - پیروزی - شهرک - بهارستان - ملکشاه - بلوار - امام - رضا - بلوار - ملا - صدرا - ملاصدرا - جهانشهر - کسری - شمالی - کسری - جنوبی - بلوار - ماهان - بلوار - بهارستان - فرمانداری - رجایی - شهر - گوهر - دشت - بلوار - رستاخیز - بلوار - شهرداری - بلوار - انقلاب - اوقافی - محمود - اباد - باغستان - باغستان - غربی - خیابان - قلم - بنیاد - شاهین - ویلا - جواد - اباد - کوی - داریوش - شهرک - یاس - حصارک - بالا - حصارک - پایین - کمال - اباد - خرمدشت - پیشاهنگی - نظر - اباد - هشتگرد - شهرک - رازی - مهر - شهر - بلوار - ارم - حسین - اباد - مهر - شهر - کیانمهر - کیان - مهر - فاز - چهار - 4 - مهر - شهر - 45متری - چهل - و- پنج - متری - گلشهر - شهرک - مترو - شهرک - پردیسان - شهرک - سلمان - فارسی - دهقان - ویلای - اول - دهقان - ویلای - دوم - میانجاده - حیدر - اباد - کرج - نو - سه - راه - گوهر - دشت - بلوار - سه - باندی - کوی - داریوش - زمین - های - خانم - انصاری - کوی - کارمندان - شمالی - کوی - کارمندان - جنوبی - مهر - ویلا - بلوار - دانش - اموز - آموز - دولت - اباد - چهار - صد - دستگاه - هفت - تیر - محمد - شهر - شهرک - مهندسی - زراعی - فردیس - شهرک - وحدت - شهرک - منظریه - ساسانی - فردوسی - رزکان - نو - قلمستان - مصباح - کلاک - بالا - کلاک -پایین - کلاک - شهرداری - گرمدره - شهرک - جهان - نما - شهرک - خاتم - حسین - آباد - راهن - منیریه - گمرک - نازی‌ - آباد - خانی‌ - آباد - خزانه - کیان‌ - شهر - بریانک - پیروزی - نیرو - هوایی - صفا - افسریه - بهارستان - دروازه - شمیران - شکوفه - مشیریه - شهر - ری - نازی - آباد - میدان - خراسان - خاوران - سعادت - آباد - شهرک - غرب - پونک - جی - باغ فیض - شهران - ستارخان - صادقیه - گیشا - اکباتان - سردار - جنگل - کاشانی - المپیک - آزادی - درکه - تهرانسر - شهرآرا - شهرزیبا - مرزداران - فردوس - اوین - ایوانک - نیاوران - دزاشیب - پاسداران - فرمانیه - ازگل - ارتش - تجریش - زعفرانیه - قیطریه - چیذر - اختیاریه - قلهک - ظفر - میرداماد - جردن - نوبنیاد - نو بنیاد - شریعتی - هفت تیر - یوسف آباد - سهروردی - وزرا - الهیه - گاندی - تهرانپارس - حکیمیه - رسالت - هفت - حوض - سراج - دلاوران - شمیران - نو - هنگام - نارمک - مجیدیه - بهار - سبلان - دردشت - نظام - آباد - علم - و - صنعت - پیروزی - پلیس - کرمان - مدنی - امام - حسین - تهران - نو</h5>
<h6 class="style-pf-secret-key-words"> ارج - تعمیر - تعمیرات - رفع - ایراد - ایرادات - مشکل - وسیله ی مورد نظر - ماشین - دوقلو - درب - از - بالا - در - استان - تهران - البرز - کرج - خشک - کن - دار-اتوماتیک - تعمیر مارکت - تعمیرگاه - خدمات - مجاز - مرکزی - سرویس - نصب - جاده - چالوس - زنبق -عظیمیه -بعثت - طالقانی - شمالی - طالقانی - جنوبی - میدان - اسبی - میدان - مهران - بلوار - کاج - پامچال - شمالی - پامچال - جنوبی - برغان - اسلام - اباد - آباد - ازادگان - آزادگان - حسن - اباد- آباد - نواب - مطهری - میدان - نبوت - بلوار - جمهوری - شمالی - بلوار - جمهوری - جنوبی - بلوار - موذن - اشتراکی - شمالی - اشتراکی - جنوبی - کوی - پیروزی - شهرک - بهارستان - ملکشاه - بلوار - امام - رضا - بلوار - ملاصدرا - ملا صدرا - جهانشهر - کسری - شمالی - کسری - جنوبی - بلوار - ماهان - بلوار - بهارستان - فرمانداری - رجایی - شهر - گوهر - دشت - بلوار - رستاخیز - بلوار - شهرداری - بلوار - انقلاب - اوقافی - محمود - اباد - باغستان - باغستان - غربی - خیابان - قلم - بنیاد - شاهین - ویلا - جواد - اباد - کوی - داریوش - شهرک - یاس - حصارک - بالا - حصارک - پایین - کمال - اباد - خرمدشت - پیشاهنگی - نظر - اباد - هشتگرد - شهرک - رازی - مهر - شهر- بلوار - ارم - حسین - اباد - مهرشهر - کیانمهر - فاز - 4 - مهر - شهر - 45 -متری - گلشهر - شهرک - مترو- شهرک - پردیسان - شهرک - سلمان - فارسی - دهقان - ویلای - اول - دهقان - ویلای - دوم - میانجاده - حیدر - اباد - کرج - نو - سه - راه - گوهر - دشت - بلوار - سه - باندی - کوی - داریوش - زمین - های - خانم - انصاری - کوی - کارمندان - شمالی - کوی - کارمندان - جنوبی - مهر - ویلا - بلوار - دانش - اموز - دولت - اباد - چهار - صد - دستگاه - هفت - تیر - محمد - شهر - شهرک - مهندسی - زراعی - فردیس - شهرک - وحدت - شهرک - منظریه - ساسانی - فردوسی - رزکان - نو - قلمستان - مصباح - کلاک - بالا - کلاک - پایین - کلاک -  شهرداری - گرمدره - شهرک - جهان - نما - شهرک - خاتم - حسین - آباد - راهن - راه - آهن - اهن - جاده - چالوس - زنبق - عظیمیه - بعثت - طالقانی - شمالی - طالقانی - جنوبی - میدان - اسبی - میدان - مهران - بلوار - کاج - پامچال - شمالی - پامچال - جنوبی - برغان - اسلام - اباد - ازادگان - حسن - اباد - نواب - مطهری - میدان - نبوت - بلوار - جمهوری - شمالی - بلوار - جمهوری - جنوبی - بلوار - موذن - اشتراکی - شمالی - اشتراکی - جنوبی - کوی - پیروزی - شهرک - بهارستان - ملکشاه - بلوار - امام - رضا - بلوار - ملا - صدرا - ملاصدرا - جهانشهر - کسری - شمالی - کسری - جنوبی - بلوار - ماهان - بلوار - بهارستان - فرمانداری - رجایی - شهر - گوهر - دشت - بلوار - رستاخیز - بلوار - شهرداری - بلوار - انقلاب - اوقافی - محمود - اباد - باغستان - باغستان - غربی - خیابان - قلم - بنیاد - شاهین - ویلا - جواد - اباد - کوی - داریوش - شهرک - یاس - حصارک - بالا - حصارک - پایین - کمال - اباد - خرمدشت - پیشاهنگی - نظر - اباد - هشتگرد - شهرک - رازی - مهر - شهر - بلوار - ارم - حسین - اباد - مهر - شهر - کیانمهر - کیان - مهر - فاز - چهار - 4 - مهر - شهر - 45متری - چهل - و- پنج - متری - گلشهر - شهرک - مترو - شهرک - پردیسان - شهرک - سلمان - فارسی - دهقان - ویلای - اول - دهقان - ویلای - دوم - میانجاده - حیدر - اباد - کرج - نو - سه - راه - گوهر - دشت - بلوار - سه - باندی - کوی - داریوش - زمین - های - خانم - انصاری - کوی - کارمندان - شمالی - کوی - کارمندان - جنوبی - مهر - ویلا - بلوار - دانش - اموز - آموز - دولت - اباد - چهار - صد - دستگاه - هفت - تیر - محمد - شهر - شهرک - مهندسی - زراعی - فردیس - شهرک - وحدت - شهرک - منظریه - ساسانی - فردوسی - رزکان - نو - قلمستان - مصباح - کلاک - بالا - کلاک -پایین - کلاک - شهرداری - گرمدره - شهرک - جهان - نما - شهرک - خاتم - حسین - آباد - راهن - منیریه - گمرک - نازی‌ - آباد - خانی‌ - آباد - خزانه - کیان‌ - شهر - بریانک - پیروزی - نیرو - هوایی - صفا - افسریه - بهارستان - دروازه - شمیران - شکوفه - مشیریه - شهر - ری - نازی - آباد - میدان - خراسان - خاوران - سعادت - آباد - شهرک - غرب - پونک - جی - باغ فیض - شهران - ستارخان - صادقیه - گیشا - اکباتان - سردار - جنگل - کاشانی - المپیک - آزادی - درکه - تهرانسر - شهرآرا - شهرزیبا - مرزداران - فردوس - اوین - ایوانک - نیاوران - دزاشیب - پاسداران - فرمانیه - ازگل - ارتش - تجریش - زعفرانیه - قیطریه - چیذر - اختیاریه - قلهک - ظفر - میرداماد - جردن - نوبنیاد - نو بنیاد - شریعتی - هفت تیر - یوسف آباد - سهروردی - وزرا - الهیه - گاندی - تهرانپارس - حکیمیه - رسالت - هفت - حوض - سراج - دلاوران - شمیران - نو - هنگام - نارمک - مجیدیه - بهار - سبلان - دردشت - نظام - آباد - علم - و - صنعت - پیروزی - پلیس - کرمان - مدنی - امام - حسین - تهران - نو</h6>

<script src="JS/js.min.js"></script>
<!-- end script files  -->
</body>
</html>