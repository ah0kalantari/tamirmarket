<!DOCTYPE html>
<html lang="en-fa" >
<head>
    <meta charset="UTF-8">
    <meta name="description" content="تعمیر مارکت در زمینه تعمیرات تخصصی انواع لوازم خانگی و برد های الکترونیکی با متخصصان با تجربه آماده خدمت رسانی به شماست.">
    <link rel="stylesheet" href="css/css.min.css">
    <link rel="stylesheet" href="ItroDesign.min.css">
    <link rel="shortcut icon" href="img/favicon.ico" type="image/x-icon">
    <meta name="keywords" content=" ارج - تعمیر - تعمیرات - رفع - ایراد - ایرادات - مشکل - وسیله ی مورد نظر - ماشین - دوقلو - درب - از - بالا - در - استان - تهران - البرز - کرج - خشک - کن - دار-اتوماتیک - تعمیر مارکت - تعمیرگاه - خدمات - مجاز - مرکزی - سرویس - نصب - جاده - چالوس - زنبق -عظیمیه -بعثت - طالقانی - شمالی - طالقانی - جنوبی - میدان - اسبی - میدان - مهران - بلوار - کاج - پامچال - شمالی - پامچال - جنوبی - برغان - اسلام - اباد - آباد - ازادگان - آزادگان - حسن - اباد- آباد - نواب - مطهری - میدان - نبوت - بلوار - جمهوری - شمالی - بلوار - جمهوری - جنوبی - بلوار - موذن - اشتراکی - شمالی - اشتراکی - جنوبی - کوی - پیروزی - شهرک - بهارستان - ملکشاه - بلوار - امام - رضا - بلوار - ملاصدرا - ملا صدرا - جهانشهر - کسری - شمالی - کسری - جنوبی - بلوار - ماهان - بلوار - بهارستان - فرمانداری - رجایی - شهر - گوهر - دشت - بلوار - رستاخیز - بلوار - شهرداری - بلوار - انقلاب - اوقافی - محمود - اباد - باغستان - باغستان - غربی - خیابان - قلم - بنیاد - شاهین - ویلا - جواد - اباد - کوی - داریوش - شهرک - یاس - حصارک - بالا - حصارک - پایین - کمال - اباد - خرمدشت - پیشاهنگی - نظر - اباد - هشتگرد - شهرک - رازی - مهر - شهر- بلوار - ارم - حسین - اباد - مهرشهر - کیانمهر - فاز - 4 - مهر - شهر - 45 -متری - گلشهر - شهرک - مترو- شهرک - پردیسان - شهرک - سلمان - فارسی - دهقان - ویلای - اول - دهقان - ویلای - دوم - میانجاده - حیدر - اباد - کرج - نو - سه - راه - گوهر - دشت - بلوار - سه - باندی - کوی - داریوش - زمین - های - خانم - انصاری - کوی - کارمندان - شمالی - کوی - کارمندان - جنوبی - مهر - ویلا - بلوار - دانش - اموز - دولت - اباد - چهار - صد - دستگاه - هفت - تیر - محمد - شهر - شهرک - مهندسی - زراعی - فردیس - شهرک - وحدت - شهرک - منظریه - ساسانی - فردوسی - رزکان - نو - قلمستان - مصباح - کلاک - بالا - کلاک - پایین - کلاک -  شهرداری - گرمدره - شهرک - جهان - نما - شهرک - خاتم - حسین - آباد - راهن - راه - آهن - اهن - جاده - چالوس - زنبق - عظیمیه - بعثت - طالقانی - شمالی - طالقانی - جنوبی - میدان - اسبی - میدان - مهران - بلوار - کاج - پامچال - شمالی - پامچال - جنوبی - برغان - اسلام - اباد - ازادگان - حسن - اباد - نواب - مطهری - میدان - نبوت - بلوار - جمهوری - شمالی - بلوار - جمهوری - جنوبی - بلوار - موذن - اشتراکی - شمالی - اشتراکی - جنوبی - کوی - پیروزی - شهرک - بهارستان - ملکشاه - بلوار - امام - رضا - بلوار - ملا - صدرا - ملاصدرا - جهانشهر - کسری - شمالی - کسری - جنوبی - بلوار - ماهان - بلوار - بهارستان - فرمانداری - رجایی - شهر - گوهر - دشت - بلوار - رستاخیز - بلوار - شهرداری - بلوار - انقلاب - اوقافی - محمود - اباد - باغستان - باغستان - غربی - خیابان - قلم - بنیاد - شاهین - ویلا - جواد - اباد - کوی - داریوش - شهرک - یاس - حصارک - بالا - حصارک - پایین - کمال - اباد - خرمدشت - پیشاهنگی - نظر - اباد - هشتگرد - شهرک - رازی - مهر - شهر - بلوار - ارم - حسین - اباد - مهر - شهر - کیانمهر - کیان - مهر - فاز - چهار - 4 - مهر - شهر - 45متری - چهل - و- پنج - متری - گلشهر - شهرک - مترو - شهرک - پردیسان - شهرک - سلمان - فارسی - دهقان - ویلای - اول - دهقان - ویلای - دوم - میانجاده - حیدر - اباد - کرج - نو - سه - راه - گوهر - دشت - بلوار - سه - باندی - کوی - داریوش - زمین - های - خانم - انصاری - کوی - کارمندان - شمالی - کوی - کارمندان - جنوبی - مهر - ویلا - بلوار - دانش - اموز - آموز - دولت - اباد - چهار - صد - دستگاه - هفت - تیر - محمد - شهر - شهرک - مهندسی - زراعی - فردیس - شهرک - وحدت - شهرک - منظریه - ساسانی - فردوسی - رزکان - نو - قلمستان - مصباح - کلاک - بالا - کلاک -پایین - کلاک - شهرداری - گرمدره - شهرک - جهان - نما - شهرک - خاتم - حسین - آباد - راهن - منیریه - گمرک - نازی‌ - آباد - خانی‌ - آباد - خزانه - کیان‌ - شهر - بریانک - پیروزی - نیرو - هوایی - صفا - افسریه - بهارستان - دروازه - شمیران - شکوفه - مشیریه - شهر - ری - نازی - آباد - میدان - خراسان - خاوران - سعادت - آباد - شهرک - غرب - پونک - جی - باغ فیض - شهران - ستارخان - صادقیه - گیشا - اکباتان - سردار - جنگل - کاشانی - المپیک - آزادی - درکه - تهرانسر - شهرآرا - شهرزیبا - مرزداران - فردوس - اوین - ایوانک - نیاوران - دزاشیب - پاسداران - فرمانیه - ازگل - ارتش - تجریش - زعفرانیه - قیطریه - چیذر - اختیاریه - قلهک - ظفر - میرداماد - جردن - نوبنیاد - نو بنیاد - شریعتی - هفت تیر - یوسف آباد - سهروردی - وزرا - الهیه - گاندی - تهرانپارس - حکیمیه - رسالت - هفت - حوض - سراج - دلاوران - شمیران - نو - هنگام - نارمک - مجیدیه - بهار - سبلان - دردشت - نظام - آباد - علم - و - صنعت - پیروزی - پلیس - کرمان - مدنی - امام - حسین - تهران - نو">
    
    <title> تعمیر مارکت | Tamir Market home appliances repair</title>
</head>
<body class="styles-of-body-tag">
        <header class="position-of-menu style-of-menu">
        <div class="style-of-all-menu display-none-mo">
            <div>
                <div>
                    <img onclick="dispalymenuitems()" src="img/menu/menu icon.png" id="display-of-menu-icon"     alt="تعمیر مارکت" class="style-of-menu-icon-in-mo"></img>
                    <img onclick="bardispalymenuitems()" src="img/menu/zarbdar.png" id="display-of-menu-zarbdar" alt="تعمیر مارکت" class="style-of-menu-icon-zarbdar-in-mo"></img>
                        <nav id="style-of-all-menu-mo">
                            <ul class="display-inline">
                                <li class="display-inline"><a class="style-of-sdf style-of-original-page-item-in-menu-for-mo z-index-of-orginal-item-of-menu" href="index.php">صفحه ی اصلی </a></li>
                                <div onmouseover="showzirmajmoee()" class="style-of-temirat-in-menu-and-open-or-close">
                                    <li  class="display-inline z-index-of-orginal-item-of-menu"> <a class="style-of-sdf z-index-of-orginal-item-of-menu">تعمیرات</a>
                                       <div id="99900999" class="display-inline" onmouseover="showzirmajmoee()" onmouseout="hidezirmajmoee()">
                                         <ul id="style-of-zirmenu-of-tamirat" class="style-of-zirmenu-of-tamirat">
                                            <li onmouseover="showzirmajmoee2()" onmouseout="hidezirmajmoee2()" class="style-of-sdf background-color-0e4797-hover"><a class="style-of-text-of-zirmenus style-of-sdf"  >لوازم خانگی</a>
                                                <ul id="style-of-zirmenu-of-tamirat2" class="style-of-zirmenu-of-tamirat2" class="style-of-all-of-zirmajmoee">
                                                    <li class="style-of-sdf"><a class="style-of-text-of-zirmenus style-of-sdf" title="تعمیرات ماشین لباسشویی | تعمیر مارکت" href="RepairWashingMachine.php"> ماشین لباسشویی</a></li>
                                                    <li class="style-of-sdf"><a class="style-of-text-of-zirmenus style-of-sdf" title="تعمیرات یخچال فریزر | تعمیر مارکت" href="RepairRefrigerator.php">یخچال/فریزر </a></li>
                                                    <li class="style-of-sdf"><a class="style-of-text-of-zirmenus style-of-sdf" title="تعمیرات ساید بای ساید | تعمیر مارکت" href="RepairSideBySide.php">ساید بای ساید</a></li>
                                                    <li class="style-of-sdf"><a class="style-of-text-of-zirmenus style-of-sdf" title="تعمیرات ظرفشویی | تعمیر مارکت" href="RepairDishwasher.php"> ظرفشویی</a></li>
                                                    <li class="style-of-sdf"><a class="style-of-text-of-zirmenus style-of-sdf" title="تعمیرات ماکروفر ( سولاردام ، ماکروویو ) | تعمیر مارکت" href="RepairMicrowave.php"> ماکروویو</a></li>
                                                    <li class="style-of-sdf"><a class="style-of-text-of-zirmenus style-of-sdf" title="تعمیرات کولر آبی و گازی | تعمیر مارکت" href="RepairAirConditioning.php"> کولر آبی/گازی</a></li>
                                                    <li class="style-of-sdf"><a class="style-of-text-of-zirmenus style-of-sdf" title="تعمیرات جاروبرقی | تعمیر مارکت" href="RepairVacuumeCleaner.php"> جاروبرقی </a></li>
                                                    <li class="style-of-sdf"><a class="style-of-text-of-zirmenus style-of-sdf" title="تعمیرات لوازم برقی آشپزخانه | تعمیر مارکت" href="RepairKitchenAppliances.php">لوازم آشپزخانه </a></li>
                                                </ul>
                                            </li>
                                            <br class="display-none-pc">
                                            <li onmouseover="showzirmajmoee3()" onmouseout="hidezirmajmoee3()" class="style-of-sdf border-top-of-menu"><a class="style-of-text-of-zirmenus"  >برد های الکترونیکی</a>
                                                <ul id="style-of-zirmenu-of-tamirat3" class="style-of-zirmenu-of-tamirat3">
                                                    <li class="style-of-sdf"><a class="style-of-text-of-zirmenus">
                                                         <a class="style-of-text-of-zirmenus style-of-sdf" title="تعمیرات برد الکترونیکی لوازم خانگی | تعمیر مارکت" href="RepairHomeBoard.php">برد لوازم خانگی</a> 
                                                    </li>
                                                    <li class="style-of-sdf"><a class="style-of-text-of-zirmenus">
                                                         <a class="style-of-text-of-zirmenus style-of-sdf" title="تعمیرات برد های الکترونیکی دستگاه های صنعتی | تعمیر مارکت" href="RepairFactoryBoard.php">برد دستگاه های صنعتی</a> 
                                                    </li>
                                                </ul>
                                            </li>
                                            <br class="display-none-pc">
                                            <!-- سیم پیچی = sim -->
                                            <li onmouseover="showzirmajmoee4()" onmouseout="hidezirmajmoee4()" class="style-of-sdf border-top-of-menu"><a class="style-of-text-of-zirmenus"  >سیم پیچی موتور</a>
                                                <ul id="style-of-zirmenu-of-tamirat4" class="style-of-zirmenu-of-tamirat4">
                                                    <li class="style-of-sdf">
                                                         <a class="style-of-text-of-zirmenus" title="سیم پیچی موتور تک فاز | تعمیر مارکت" href="SimSeFazMotor.php">سه فاز</a> 
                                                    </li>
                                                    <br class="display-none-pc">
                                                    <li class="style-of-sdf">
                                                        <a class="style-of-text-of-zirmenus" title="سیم پیچی موتور سه فاز | تعمیر مارکت" href="SimTakFazMotor.php">تک فاز</a>
                                                    </li>
                                                    <br class="display-none-pc">
                                                    <li class="style-of-sdf">
                                                        <a class="style-of-text-of-zirmenus" title="سیم پیچی موتور ترانس | تعمیر مارکت" href="SimTrans.php">ترانس</a>
                                                    </li>
                                                </ul>
                                            </li>
                                        </ul>  
                                       </div>
                                        
                                    </li>
                                </div>
                                    <br class="display-none-pc">
                                    <li class="display-inline z-index-of-orginal-item-of-menu"> <a href="errors/errors.php" class="style-of-sdf z-index-of-orginal-item-of-menu">ارور ها</a></ul>
                                    </li>
                                <br class="display-none-pc">
                                <li class="display-inline"><a class="style-of-sdf" href="learn.php">آموزش</a></li>
                                <br class="display-none-pc">
                                <li class="display-inline"><a class="style-of-sdf" href="EtalaatOmomee.php">بیشتر بدانیم</a></li>
                                <br class="display-none-pc">
                                <li class="display-inline"><a class="style-of-sdf" href="AboutUs.php">درباره ما</a></li>
                                <br class="display-none-pc">
                                <li class="display-inline"><a class="style-of-sdf" href="ContactUs.php">تماس با ما</a></li>
                                <br class="display-none-pc">
                                <li class="display-inline style-of-sabt-sefaresh-li-in-menu"><a class="style-of-sdf style-of-sabt-sefaresh-in-menu" href="SabtSefaresh.php">ثبت سفارش</a></li>
                                <br class="display-none-pc">
                            </ul>
                        </nav>
                    </div>
                </div>
            </div>
            <!-- منوی موبایل زیر منوی کامپیوتر بالا -->
            <div id="style-of-all-menu" class="style-of-all-menu display-none-pc">
                <div>
                    <div>
                        <img onclick="ChangeAlamatOfMenu()" id="style-hamberger-in-menu-mo" class="style-hamberger-in-menu-mo" src="img/menu/menu icon.png"  alt="تعمیر مارکت"></img>
                        <img onclick="ChangeAlamatOfMenu()" id="style-x-in-menu-mo" class="style-x-in-menu-mo" src="img/menu/zarbdar.png"    alt="تعمیر مارکت"></img>
                            <nav id="display-of-all-menu-in-mo" class="display-of-all-menu-in-mo">
                                <ul>
                                    <li  class="style-of-menu-text-in-mo"><a  class="style-of-menu-text-in-mo" href="index.php">صفحه ی اصلی </a></li>
                                    <div><hr class="white-hr">
                                        <li class="style-of-menu-text-in-mo"><a class="style-of-menu-text-in-mo" onclick="displayOfZirMenuInMo1()">تعمیرات</a><hr class="white-hr">
                                           <div id="display-of-zir-menu-in-mo1" class="display-of-zir-menu-in-mo1">
                                             <ul>
                                                <li class="style-of-menu-text-in-mo" onclick="displayOfZirMenuInMo2()"><a>لوازم خانگی</a><hr class="white-hr">
                                                    <ul id="display-of-zir-menu-in-mo2" class="display-of-zir-menu-in-mo2">
                                                        <li class="style-of-menu-text-in-mo"><a class="style-of-menu-text-in-mo" href="RepairWashingMachine.php"> ماشین لباسشویی</a></li><hr class="white-hr">
                                                        <li class="style-of-menu-text-in-mo"><a class="style-of-menu-text-in-mo" href="RepairRefrigerator.php">یخچال/فریزر </a></li><hr class="white-hr">
                                                        <li class="style-of-menu-text-in-mo"><a class="style-of-menu-text-in-mo" href="RepairSideBySide.php">ساید بای ساید</a></li><hr class="white-hr">
                                                        <li class="style-of-menu-text-in-mo"><a class="style-of-menu-text-in-mo" href="RepairDishwasher.php"> ماشین ظرفشویی</a></li><hr class="white-hr">
                                                        <li class="style-of-menu-text-in-mo"><a class="style-of-menu-text-in-mo" href="RepairMicrowave.php"> ماکروویو</a></li><hr class="white-hr">
                                                        <li class="style-of-menu-text-in-mo"><a class="style-of-menu-text-in-mo" href="RepairAirConditioning.php"> کولر آبی/گازی</a></li><hr class="white-hr">
                                                        <li class="style-of-sdf"><a class="style-of-text-of-zirmenus style-of-sdf" title="تعمیرات جاروبرقی | تعمیر مارکت" href="RepairVacuumeCleaner.php"> جاروبرقی </a></li>
                                                        <li class="style-of-menu-text-in-mo"><a class="style-of-menu-text-in-mo" href="RepairKitchenAppliances.php">لوازم آشپزخانه </a></li><hr class="white-hr">
                                                    </ul>
                                                </li>
                                                <li class="style-of-menu-text-in-mo" onclick="displayOfZirMenuInMo3()"><a>برد های الکترونیکی</a><hr class="white-hr">
                                                    <ul id="display-of-zir-menu-in-mo3" class="display-of-zir-menu-in-mo3">
                                                        <li class="style-of-menu-text-in-mo">
                                                             <a class="style-of-menu-text-in-mo" href="RepairHomeBoard.php">برد لوازم خانگی</a> <hr class="white-hr">
                                                        </li>
                                                        <li class="style-of-menu-text-in-mo">
                                                             <a class="style-of-menu-text-in-mo" href="RepairFactoryBoard.php">برد دستگاه های صنعتی</a> <hr class="white-hr">
                                                        </li>
                                                    </ul>
                                                </li>
                                                <!-- سیم پیچی = sim -->
                                                <li class="style-of-menu-text-in-mo" onclick="displayOfZirMenuInMo4()"><a>سیم پیچی موتور</a><hr class="white-hr">
                                                    <ul id="display-of-zir-menu-in-mo4" class="display-of-zir-menu-in-mo4">
                                                        <li class="style-of-menu-text-in-mo">
                                                             <a class="style-of-menu-text-in-mo" href="SimSeFazMotor.php">سه فاز</a> <hr class="white-hr">
                                                        </li>
                                                        <li class="style-of-menu-text-in-mo">
                                                            <a class="style-of-menu-text-in-mo" href="SimTakFazMotor.php">تک فاز</a><hr class="white-hr">
                                                        </li>
                                                        <li class="style-of-menu-text-in-mo">
                                                            <a class="style-of-menu-text-in-mo" href="SimTrans.php">ترانس</a><hr class="white-hr">
                                                        </li>
                                                    </ul>
                                                </li>
                                            </ul>  
                                           </div>
                                            
                                        </li>
                                    </div>
                                        <li class="style-of-menu-text-in-mo"> <a class="style-of-menu-text-in-mo" href="errors/errors.php">ارور ها</a><hr class="white-hr">
                                        </li>
                                    <li class="style-of-menu-text-in-mo"><a class="style-of-menu-text-in-mo" href="learn.php">آموزش</a></li><hr class="white-hr">
                                    <li class="style-of-menu-text-in-mo"><a class="style-of-menu-text-in-mo" href="EtalaatOmomee.php">بیشتر بدانیم</a></li><hr class="white-hr">
                                    <li class="style-of-menu-text-in-mo"><a class="style-of-menu-text-in-mo" href="AboutUs.php">درباره ما</a></li><hr class="white-hr">
                                    <li class="style-of-menu-text-in-mo"><a class="style-of-menu-text-in-mo" href="ContactUs.php">تماس با ما</a></li><hr class="white-hr">
                                    <li class="style-of-menu-text-in-mo"><a class="style-of-menu-text-in-mo" href="SabtSefaresh.php">ثبت سفارش</a></li><hr class="white-hr">
                                </ul>
                            </nav>
                        </div>
                    </div>
                </div>
        </header>
    <p id="show-menu-button" onclick="show_menu_desktop()" class="style-show-menu-button"> < </p>
    <div class="first-logo-styles">
        <br><br><br><br class=pc"><br class=pc">
        <img class="display-inline styles-of-first-logo-in-all-pages-1" src="img/firstlogo/لوگوی تعمیر مارکت.png"alt="Tamir Market تعمیر مارکت">
        <img class="display-inline styles-of-first-logo-in-all-pages-2" src="img/firstlogo/تعمیر مارکت.png" alt="Tamir Market تعمیر مارکت">
        <hr class="style-of-hr-in-bottom-of-first-logo-in-all-pages">
    </div>

    <table>
        <br><br>
        <tr class="chooseRGorSBS-tr">
            <td class="chooseRGorSBS-td">
            <a class="text-decoration-none style-of-chooseRGorSBS-a" href="RepairRefrigerator.php">
                <img class="style-of-chooseRGorSBS-img" src="img/ItemTamirat/RG.jpg"             alt="تعمیر مارکت">
                <p class="chooseRGorSBS-text">یخچال فریزر</p>
            </a>
            </td>
            <td class="chooseRGorSBS-td">
            <a class="text-decoration-none style-of-chooseRGorSBS-a" href="RepairSideBySide.php">
                <img class="style-of-chooseRGorSBS-img" src="img/ItemTamirat/sbs.jpg"             alt="تعمیر مارکت">
                <p class="chooseRGorSBS-text">ساید بای ساید</p>
            </a>
            </td>
        </tr>
    </table>




<!-- ---------------------------------------------------------------------------------------------------- -->
<!-- *** footer *** -->
<table class="style-of-footer-title display-none-mo">
    <tr>
        <td class="style-of-footer-td">
            <p class="style-of-footer-asli-title"><span class="color-green">تعمیر مارکت</span></p>
        </td>
        <td class="style-of-footer-td">
            <p class="style-of-footer-title">استان تهران</p>
        </td>
        <td class="style-of-footer-td">
            <p class="style-of-footer-title">استان البرز (کرج)</p>  
        </td>
    </tr>
    <tr>
        <td rowspan="2" class="style-of-footer-td">
            <img class="style-of-footer-logo" src="img/firstlogo/ لوگوی تعمیر مارکت.png" alt="تعمیر مارکت">
        </td>
        <td class="style-of-footer-td">
            <a class="style-of-footer-a">
                <p class="style-of-footer-title">۰۹۱۲-۳۲۰۲۰۱۳</p>  
            </a>
        </td>
        <td class="style-of-footer-td">
            <a class="style-of-footer-a">
                <p class="style-of-footer-title">۰۲۶-۳۴۲۱۳۹۸۵</p>  
            </a>
        </td>
    </tr>
    <tr>
        <td class="style-of-footer-td">
            <a class="style-of-footer-a">
                <p class="style-of-footer-title">۰۹۱۲-۲۲۴۶۰۴۶</p>  
            </a>
        </td>
        <td class="style-of-footer-td">
            <a class="style-of-footer-a">
                <p class="style-of-footer-title">۰۲۶-۳۴۲۱۳۸۴۹</p>  
            </a>
        </td>
    </tr>
    <tr>
        <td class="style-of-footer-td">
            <p class="style-of-footer-copyright">
                تمامی حقوق برای تعمیر مارکت محفوظ می باشد ©
            </p>
        </td>
        <td class="style-of-footer-td">
            <a class="style-of-footer-a">
                <p class="style-of-footer-title">۰۹۱۲-۰۴۵۷۹۶۹</p>  
            </a>
        </td>
        <td class="style-of-footer-td">
            <a class="style-of-footer-a">
                <p class="style-of-footer-title">۰۹۱۲-۹۲۴۲۷۷۶</p>  
            </a>
        </td>
    </tr>
    <tr>
        <td class="style-of-footer-td"> 
            <a class="style-of-footer-made-by-ITROSOFT"  href="#">
                <p class="style-of-footer-made-by-ITROSOFT">ساخته شده توسط Itro Programming</p>
            </a>
        </td>
        <td class="style-of-footer-td">
            <a class="style-of-footer-a">
                <p class="style-of-footer-title">۰۹۱۲-۹۲۴۲۷۸۱</p>  
            </a>
        </td>
        <td class="style-of-footer-td">
            <p class="style-of-footer-address">
                آدرس:
                کرج، خیابان شهید بهشتی، بلوار امام خمینی، نرسیده به دانشگاه رسام، ساختمان سپاس
            </p>  
        </td>
    </tr>
    </table>
    <table class="style-of-footer-title display-none-pc">
    <tr>
    <td class="style-of-footer-td">
        <p class="style-of-footer-asli-title"><span class="color-green">تعمیر مارکت</span></p>
    </td>
    </tr>
    <tr>
    <td class="style-of-footer-td">
        <img class="style-of-footer-logo" src="img/firstlogo/ لوگوی تعمیر مارکت.png" alt="تعمیر مارکت">
    </td>
    </tr>
    <tr>
        <td class="style-of-footer-td">
            <p class="style-of-footer-title">استان تهران</p>
        </td>
    </tr>
    <tr>
        <td class="style-of-footer-td">
            <a class="style-of-footer-a">
                <p class="style-of-footer-title">۰۹۱۲-۳۲۰۲۰۱۳ - ۰۹۱۲-۲۲۴۶۰۴۶</p>  
            </a>
        </td>
    </tr>
    <tr>
    
    </tr>
    <tr>
        <td class="style-of-footer-td">
            <a class="style-of-footer-a">
                <p class="style-of-footer-title">۰۹۱۲-۰۴۵۷۹۶۹ - ۰۹۱۲-۹۲۴۲۷۸۱</p>  
            </a>
        </td>
    </tr>
     
    </tr>
    <tr>
        <td class="style-of-footer-td">
            <p class="style-of-footer-title">استان البرز (کرج)</p>  
        </td>
    </tr>
    <tr>
        <td class="style-of-footer-td">
            <a class="style-of-footer-a">
                <p class="style-of-footer-title">۰۲۶-۳۴۲۱۳۹۸۵ - ۰۲۶-۳۴۲۱۳۸۴۹</p>  
            </a>
        </td>
    </tr>
    <tr>
        <td class="style-of-footer-td">
            <a class="style-of-footer-a">
                <p class="style-of-footer-title">۰۹۱۲-۹۲۴۲۷۷۶</p>  
            </a>
        </td>
    </tr>
    <tr>
        <td class="style-of-footer-td">
            <p class="style-of-footer-address">
                آدرس:
                کرج، خیابان شهید بهشتی، بلوار امام خمینی، نرسیده به دانشگاه رسام، ساختمان سپاس
            </p>  
        </td>
    </tr>
    <tr>
        <td class="style-of-footer-td">
            <p class="style-of-footer-copyright">
                تمامی حقوق برای تعمیر مارکت محفوظ می باشد ©
            </p>
        </td>
    </tr>
    <tr>
        <td class="style-of-footer-td"> 
            <a class="style-of-footer-made-by-ITROSOFT"  href="#">
                <p class="style-of-footer-made-by-ITROSOFT">ساخته شده توسط Itro Programming</p>
            </a>
        </td>
    </tr>
    </table>
    <!-- end *** footer *** -->
    <!-- ---------------------------------------------------------------------------------------------------- -->
<!-- script files  -->
<script src="JS/js.min.js"></script>
<!-- end script files  -->
</body>
</html>