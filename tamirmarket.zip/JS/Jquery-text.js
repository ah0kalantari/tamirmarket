$("#fehrest-blog").click(function(){
    $("#bbvbsm1").slideToggle(300);
});
$("#mataleb-pish").click(function(){
    $("#bbvbsm2").slideToggle(300);
});
$("#BVB2").click(function(){
    $("#BVBZ2").slideToggle(300);
});




console.log("jquery text in loaded !!");

document.getElementById("loading-gif-back").style.display=("none");
document.getElementById("loading-gif").style.width=("0px");